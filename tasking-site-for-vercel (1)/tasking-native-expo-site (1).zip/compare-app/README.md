# Tasking

Expo (SDK 58) app that compares two images or videos against a project's guidelines, and builds
trap tasks with an AI-drawn image. It calls the Anthropic API directly.

## API key

Open Settings in the app, paste your Anthropic API key, tap Save key, then Test key. The key is
kept in the phone's secure storage. Never put a key in the source code: anyone can read it out of
a built app.

## What's in the app

- Compare images or videos against a guide, with six rubrics (plus audio for videos, from your notes).
- Lumiere Studio: the AI builds a blind-spot trap task, draws or sources the image, tests the trap
  against a model, and reviews it against the playbook.
- Page assistant: snap or pick a webpage screenshot and the AI answers the question on it.
  Text recognition runs on the phone (development or release builds only, not Expo Go).
- Access codes: the app stays locked until the server confirms a code. See `server/README.md`
  for the one-time database setup and the admin panel.

## Run locally

```bash
npm install
npx expo start
```

The app uses native modules (camera, secure storage, image tools), so open it in a
development build rather than Expo Go.

## Build with EAS

```bash
npm install -g eas-cli
eas login
eas build --platform android --profile preview       # installable APK
eas build --platform android --profile development   # development build
eas build --platform android --profile production    # Play Store bundle
eas build --platform ios --profile production        # needs an Apple Developer account
```

The app identifier is `com.adefila123.tasking` and the EAS project ID in `app.json` is the one the
previous APK was built with, so run `eas login` with that same Expo account. To build under a
different account, delete `extra.eas` and `updates` from `app.json` and run `eas init` again.

## Checks

```bash
npm run typecheck
npx expo-doctor
```
