// Shows the trap image (an AI-drawn SVG diagram, or a photo file) and lets the user save or share it.
import * as Sharing from "expo-sharing";
import React, { useImperativeHandle, useRef, useState } from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { SvgXml } from "react-native-svg";
import { captureRef } from "react-native-view-shot";
import { Button, T } from "./ui";

// `capture` returns the image as a file, exactly as it looks on screen, so it can be shown to a model.
export type TrapImageHandle = { capture: () => Promise<string> };

export default function TrapImage({ svg, photoUri, ref }: { svg?: string; photoUri?: string; ref?: React.Ref<TrapImageHandle> }) {
  const canvas = useRef<React.ComponentRef<typeof View>>(null);
  const [broken, setBroken] = useState(false);
  const [note, setNote] = useState("");
  const capture = async () => photoUri || (await captureRef(canvas, { format: "png", quality: 1, result: "tmpfile" }));
  useImperativeHandle(ref, () => ({ capture }));

  const share = async () => {
    setNote("");
    try {
      const uri = await capture();
      if (!(await Sharing.isAvailableAsync())) return setNote("Sharing isn't available on this device.");
      await Sharing.shareAsync(uri, { mimeType: photoUri ? "image/jpeg" : "image/png", dialogTitle: "Trap image" });
    } catch (e: any) {
      setNote(e?.message || "Could not save the image.");
    }
  };

  return (
    <View style={styles.wrap}>
      <View style={styles.frame}>
        <View ref={canvas} collapsable={false} style={styles.canvas}>
          {broken ? (
            <Text style={styles.broken}>This image could not be displayed. Make it again.</Text>
          ) : photoUri ? (
            <Image source={{ uri: photoUri }} style={styles.fill} resizeMode="contain" onError={() => setBroken(true)} />
          ) : (
            <SvgXml xml={svg || ""} width="100%" height="100%" onError={() => setBroken(true)} />
          )}
        </View>
      </View>
      <Button title="Save or share image" small onPress={share} disabled={broken} />
      {!!note && <Text style={T.error}>{note}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 8 },
  frame: { borderRadius: 8, overflow: "hidden" },
  canvas: { width: "100%", aspectRatio: 1, backgroundColor: "#fff", alignItems: "center", justifyContent: "center" },
  fill: { width: "100%", height: "100%" },
  broken: { color: "#333", padding: 16, textAlign: "center" },
});
