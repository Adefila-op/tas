// Sends two items plus a project's guidelines to the model and parses a verdict.
import * as VideoThumbnails from "expo-video-thumbnails";
import { toJpegBase64 } from "./media";
import type { GuidelineSource } from "./projects";

export type MediaItem = {
  uri: string;
  kind: "image" | "video";
  durationMs?: number;
};

export type TaskType = "video" | "image" | "generation";
export type QuestionFormat = "lumiere" | "video_annotation";

// What the person heard in each video. The judge only sees frames, so this is its only source for audio.
export type AudioNotes = { a: string; b: string };

export type Verdict = {
  winner: "A" | "B" | "tie";
  confidence: number;
  criteria: { guideline: string; A: string; B: string; better: "A" | "B" | "tie" }[];
  reason: string;
};

type Block = Record<string, any>;
type Frame = { data: string; timeMs: number };

const MODEL = "claude-sonnet-5-5";
const ENDPOINT = "https://api.anthropic.com/v1/messages";
const FRAME_COUNT = 8;
const FRAME_MAX_SIDE = 1024;
const REQUEST_TIMEOUT_MS = 180_000;

// ---------- network ----------
let activeRequest: AbortController | null = null;
let cancelled = false;

// Stops the comparison or draft that is running. Safe to call when nothing is.
export function cancelRequest() {
  cancelled = true;
  activeRequest?.abort();
}

function beginJob() { cancelled = false; }
function checkCancelled() { if (cancelled) throw new Error("Cancelled."); }

// fetch with a timeout that covers the whole exchange, body included, and readable failures.
async function request(url: string, init: RequestInit): Promise<{ ok: boolean; status: number; text: string }> {
  checkCancelled();
  const ctl = new AbortController();
  activeRequest = ctl;
  const timer = setTimeout(() => ctl.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, { ...init, signal: ctl.signal });
    return { ok: res.ok, status: res.status, text: await res.text() };
  } catch (e: any) {
    if (cancelled) throw new Error("Cancelled.");
    if (e?.name === "AbortError") throw new Error("The request timed out after 3 minutes. Try again, or use shorter items.");
    throw new Error(`Could not reach the server (${e?.message || "network error"}). Check your internet connection.`);
  } finally {
    clearTimeout(timer);
    if (activeRequest === ctl) activeRequest = null;
  }
}

function asJson(text: string): any {
  try { return JSON.parse(text); } catch { return null; }
}

function errorText(v: unknown): string {
  if (!v) return "";
  if (typeof v === "string") return v;
  const o = v as any;
  return typeof o.message === "string" ? o.message : JSON.stringify(v).slice(0, 200);
}

// ---------- verdict parsing ----------
// Make sure whatever came back has the Verdict shape, so the result screen never crashes.
function normalizeVerdict(raw: any): Verdict {
  const pick = (v: any): "A" | "B" | "tie" => {
    const t = String(v ?? "").trim().toUpperCase();
    return t === "A" || t === "B" ? t : "tie";
  };
  const conf = Number(raw?.confidence);
  const criteria = Array.isArray(raw?.criteria) ? raw.criteria : [];
  return {
    winner: pick(raw?.winner),
    confidence: Number.isFinite(conf) ? Math.min(1, Math.max(0, conf > 1 ? conf / 100 : conf)) : 0,
    criteria: criteria.map((c: any) => ({
      guideline: String(c?.guideline ?? c?.name ?? "Criterion"),
      A: String(c?.A ?? ""),
      B: String(c?.B ?? ""),
      better: pick(c?.better),
    })),
    reason: String(raw?.reason ?? raw?.explanation ?? "").trim() || "No reason was given.",
  };
}

// When the reply is prose instead of JSON, read the winner from its wording.
// The result is marked low-confidence so it is never mistaken for a clean verdict.
function fallbackVerdict(text: string): Verdict | null {
  const t = text.toLowerCase();
  const favours = (x: string) =>
    new RegExp(`\\bitem ${x}\\b[^.\\n]{0,80}\\b(better|stronger|wins|preferred|superior|more aligned|more accurate)`).test(t) ||
    new RegExp(`\\b(winner|prefer|choose|select)[^.\\n]{0,30}\\bitem ${x}\\b`).test(t);
  const a = favours("a"), b = favours("b");
  const tie = /\b(a tie|tied|equally (good|strong)|no clear winner)\b/.test(t);
  if (!a && !b && !tie) return null;
  const winner: Verdict["winner"] = a && !b ? "A" : b && !a ? "B" : "tie";
  return {
    winner,
    confidence: 0.4,
    criteria: [{
      guideline: "Visible evidence",
      A: a ? "Described as stronger or more aligned." : "No clear evidence extracted.",
      B: b ? "Described as stronger or more aligned." : "No clear evidence extracted.",
      better: winner,
    }],
    reason: `The reply was not a clean verdict, so the winner was read from its wording. Run it again for a full breakdown. Reply began: ${text.trim().slice(0, 240)}`,
  };
}

function parseVerdict(text: string, who: string): Verdict {
  const match = String(text).match(/\{[\s\S]*\}/);
  const parsed = match ? asJson(match[0]) : null;
  if (parsed) return normalizeVerdict(parsed);
  const fallback = fallbackVerdict(String(text));
  if (fallback) return fallback;
  if (!match) throw new Error(`${who} did not return a verdict. Reply was: ${String(text).slice(0, 200) || "(empty)"}`);
  throw new Error(`${who} returned a verdict that could not be read.`);
}

// ---------- items ----------
const secs = (ms: number) => `${(ms / 1000).toFixed(1)}s`;

// Evenly spaced through the video. When the length is unknown, probe the first few seconds.
function frameTimes(durationMs?: number): number[] {
  if (!durationMs || durationMs < 500) return [0, 500, 1000, 2000, 3000, 5000];
  return Array.from({ length: FRAME_COUNT }, (_, i) => Math.round(durationMs * (0.04 + (0.92 * i) / (FRAME_COUNT - 1))));
}

async function itemFrames(label: "A" | "B", item: MediaItem): Promise<Frame[]> {
  if (item.kind === "image") return [{ data: await toJpegBase64(item.uri), timeMs: 0 }];
  const frames: Frame[] = [];
  for (const time of frameTimes(item.durationMs)) {
    checkCancelled();
    try {
      const thumb = await VideoThumbnails.getThumbnailAsync(item.uri, { time, quality: 0.7 });
      const data = await toJpegBase64(thumb.uri, FRAME_MAX_SIDE);
      // past the end of a short video the decoder repeats the last frame; keep one copy
      if (frames[frames.length - 1]?.data !== data) frames.push({ data, timeMs: time });
    } catch {
      // skip a frame the decoder can't produce; the others still describe the video
    }
  }
  if (frames.length === 0) throw new Error(`Could not read any frames from video ${label}. Try recording it again.`);
  return frames;
}

function itemHeading(label: "A" | "B", item: MediaItem, frames: Frame[]): string {
  if (item.kind === "image") return `Item ${label} (image):`;
  return `Item ${label} (video, ${frames.length} frames in time order at ${frames.map((f) => secs(f.timeMs)).join(", ")}):`;
}

const imageBlock = (data: string): Block => ({ type: "image", source: { type: "base64", media_type: "image/jpeg", data } });

function guidelineBlocks(g: GuidelineSource): Block[] {
  if (g.kind === "images") {
    return [
      { type: "text", text: `PROJECT GUIDELINES (${g.images.length} photographed page(s), in order). Read every page and apply these rules exactly. Use the first page as the primary reference and work through the pages' checks in order:` },
      ...g.images.map(imageBlock),
    ];
  }
  if (g.kind === "pdf") {
    return [
      { type: "text", text: "PROJECT GUIDELINES (attached PDF). Apply these rules exactly:" },
      { type: "document", source: { type: "base64", media_type: "application/pdf", data: g.base64 } },
    ];
  }
  return [{ type: "text", text: `PROJECT GUIDELINES. Apply these rules exactly:\n\n${g.text}` }];
}

// ---------- prompts ----------
const LUMIERE_RULES = `Check both items against the Lumiere checks in the guidelines, such as: the prompt is specific and unambiguous;
there is one verifiable final answer (GTFA) in the requested format; the step-by-step solution is atomic and supports the GTFA;
there are five distractors tied to real errors; the image description is complete and does not reveal the answer;
the source and licence are eligible; the model failure is genuine and justified.
Each check is one criteria entry with better: "A" | "B" | "tie". Report failing checks plainly and quote the guideline rule they break.`;

const RUBRICS = ["Overall quality", "Instruction following", "Visual accuracy", "Reasoning quality", "Completeness", "Evidence clarity"];

const TYPE_RULES: Record<TaskType, string> = {
  video: "Both items are videos, supplied as sampled frames in time order with their timestamps. Use the order and timing of the frames to judge motion and continuity.",
  image: "Both items are images.",
  generation: "Both items are images generated from the TASK prompt. Judge prompt adherence as well as the guidelines.",
};

const hasAudioNotes = (o: CompareOptions) => !!(o.audioNotes?.a.trim() || o.audioNotes?.b.trim());

function formatRules(o: CompareOptions): string {
  if (o.format === "lumiere") return LUMIERE_RULES;
  const isVideo = o.type === "video";
  const names = isVideo ? [...RUBRICS, "Audio quality"] : RUBRICS;
  const audio = !isVideo ? "" : hasAudioNotes(o)
    ? `You cannot hear the videos. Score "Audio quality" only from the AUDIO NOTES below, written by the person who listened to both items:
judge whether the sound fits the task, its clarity, and its sync with the picture as the notes describe them, and check the notes against what the frames show.
If the notes cover only one item, say so and score that rubric "tie".`
    : `No audio was supplied and you cannot hear the videos. Score "Audio quality" as "tie" with the note "Not assessed: no audio notes",
and do not let audio affect the overall winner or your confidence. Never guess at sound from the frames.`;
  return [
    `Score exactly these ${names.length} rubrics, each independently, using the guidelines' definitions:`,
    `${names.map((n) => `"${n}"`).join(", ")}.`,
    `Each gets better: "A" | "B" | "tie" and a one to three sentence justification naming specific observed evidence.`,
    `Return a winner for every rubric, not just the overall outcome. Use the guideline as the scoring reference and the items themselves as the primary evidence. Note visual artefacts explicitly.`,
    audio,
  ].filter(Boolean).join("\n");
}

function taskText(o: CompareOptions): string {
  const taskLine = o.type === "generation"
    ? `TASK (generation prompt): ${o.question || "(none given)"}`
    : `TASK: ${o.question || "Which item is better according to the guidelines?"}`;
  const parts = [`ITEM TYPE: ${TYPE_RULES[o.type]}`, `QUESTION FORMAT:\n${formatRules(o)}`];
  if (o.type === "video" && hasAudioNotes(o)) {
    parts.push(`AUDIO NOTES (from the person who listened):\nItem A: ${o.audioNotes!.a.trim() || "(no note)"}\nItem B: ${o.audioNotes!.b.trim() || "(no note)"}`);
  }
  parts.push(taskLine);
  return parts.join("\n\n");
}

const SYSTEM = `You compare two items (Item A and Item B) strictly against the PROJECT GUIDELINES in the message.
Use the provided images as the primary visual evidence and the guideline text as the scoring reference.
Judge only what is visible or sampled. Do not reward length or effort.
Return one criteria entry for every rubric or check you are asked to score, each with a clear winner. Do not omit any.
The overall winner must follow from those entries.
Report violations honestly. Never suggest wording that hides a violation from an automated checker.
Respond with ONLY a JSON object, no prose, in this shape:
{"winner":"A"|"B"|"tie","confidence":0..1,"criteria":[{"guideline":"criterion name","A":"short note","B":"short note","better":"A"|"B"|"tie"}],"reason":"two or three sentences"}`;

export type CompareOptions = {
  type: TaskType;
  format: QuestionFormat;
  question: string;
  a: MediaItem;
  b: MediaItem;
  audioNotes?: AudioNotes;
  onProgress?: (stage: string) => void;
};

async function prepareItems(o: CompareOptions): Promise<Record<"A" | "B", Frame[]>> {
  const out = {} as Record<"A" | "B", Frame[]>;
  for (const [label, item] of [["A", o.a], ["B", o.b]] as const) {
    o.onProgress?.(item.kind === "video" ? `Reading frames from video ${label}…` : `Preparing image ${label}…`);
    out[label] = await itemFrames(label, item);
  }
  return out;
}

// Checks the key in Settings against the API without spending anything.
export async function testKey(apiKey: string): Promise<string> {
  beginJob();
  const res = await request("https://api.anthropic.com/v1/models?limit=1", {
    method: "GET",
    headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
  });
  if (res.ok) return "The key works.";
  if (res.status === 401) throw new Error("Anthropic rejected this key. Check that it was copied in full.");
  throw new Error(errorText(asJson(res.text)?.error) || `Anthropic answered ${res.status}.`);
}

async function askAnthropic(apiKey: string, body: Record<string, any>): Promise<string> {
  const res = await request(ENDPOINT, {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: MODEL, ...body }),
  });
  const data = asJson(res.text);
  if (res.status === 401) throw new Error("Anthropic rejected the API key. Check it in Settings.");
  if (!res.ok) throw new Error(errorText(data?.error) || `Request failed (${res.status})`);
  if (data?.stop_reason === "max_tokens") throw new Error("The reply was cut off before it finished. Try again.");
  return (data?.content || []).filter((c: any) => c.type === "text").map((c: any) => c.text).join("").trim();
}

export async function compareItems(apiKey: string, guidelines: GuidelineSource, o: CompareOptions): Promise<Verdict> {
  beginJob();

  const frames = await prepareItems(o);
  const content: Block[] = [...guidelineBlocks(guidelines), { type: "text", text: taskText(o) }];
  for (const [label, item] of [["A", o.a], ["B", o.b]] as const) {
    content.push({ type: "text", text: itemHeading(label, item, frames[label]) }, ...frames[label].map((f) => imageBlock(f.data)));
  }
  content.push({ type: "text", text: "Return the JSON verdict now." });
  o.onProgress?.("Asking the judge… this can take up to a minute");
  const text = await askAnthropic(apiKey, { max_tokens: 6000, system: SYSTEM, messages: [{ role: "user", content }] });
  return parseVerdict(text, "The model");
}

// ---------- Page assistant: answer the question shown on a photographed or screenshotted page ----------
export type PageAnswer = { detectedQuestion: string; extractedText: string; answer: string };

const NO_QUESTION = "I cannot see a clear question on this page; please provide the question or a clearer screenshot.";

const PAGE_RULES = [
  "You are a page-question extractor and evaluator for this screenshot.",
  "Use the screenshot image as the primary evidence and the OCR text as a support layer. The image is the source of truth for what is visible on the page.",
  "Follow this exact workflow: 1) read the visible text, 2) detect the actual question or task on the page, 3) identify visible UI elements, 4) answer only that question from the screenshot, 5) if no clear question is visible, say so plainly.",
  "Extract the visible text first, including headings, labels, instructions, buttons, captions, answer choices, and any rubric or comparison text.",
  "Then state the detected question that the page is asking.",
  "Then give the final answer yourself. Commit to one answer and ground it in the visible page evidence only. Do not tell the reader how to work it out.",
  "If the page includes a rubric, criteria, or scoring guidance, apply it to the answer and cite the visible rule from the screenshot.",
  "If PROJECT GUIDELINES are supplied, they take priority over your own judgement when they cover the question.",
  "Do not summarize the page generically. Do not say there is nothing to copy. Do not say you cannot see the image unless there is genuinely no clear question visible.",
  "Return your response in this exact format:",
  "Detected question: ...",
  "Extracted page text: ...",
  "Answer: ...",
  `If no question is visible, set Detected question to: ${NO_QUESTION}`,
].join("\n");

function parsePageAnswer(text: string): PageAnswer {
  const part = (label: string, next: string[]) => {
    const stop = next.length ? `(?=\\n\\s*(?:${next.join("|")})\\s*:|$)` : "$";
    const m = text.match(new RegExp(`${label}\\s*:\\s*([\\s\\S]*?)${stop}`, "i"));
    return m ? m[1].trim() : "";
  };
  const detectedQuestion = part("Detected question", ["Extracted page text", "Answer"]);
  const extractedText = part("Extracted page text", ["Answer"]);
  const answer = part("Answer", []);
  if (!detectedQuestion && !answer) return { detectedQuestion: "", extractedText: "", answer: text.trim() };
  return { detectedQuestion, extractedText: extractedText || "No page text was clearly extracted from the screenshot.", answer };
}

export async function analyzePage(
  apiKey: string, imageUri: string, ocrText: string, question: string, guidelines: GuidelineSource | null, onProgress?: (stage: string) => void,
): Promise<PageAnswer> {
  beginJob();
  onProgress?.("Preparing the page…");
  const page = await toJpegBase64(imageUri, 2000, 0.8);
  const ask = [
    PAGE_RULES,
    question.trim() ? `The user's question about this page: ${question.trim()}` : "Detect the comparison or guideline question visible on this page and answer it from the screenshot itself.",
    ocrText.trim() ? `OCR text on the page:\n${ocrText.trim().slice(0, 12000)}` : "",
  ].filter(Boolean).join("\n\n");
  const content: Block[] = [...(guidelines ? guidelineBlocks(guidelines) : []), imageBlock(page), { type: "text", text: ask }];
  onProgress?.("Analyzing the page… this can take up to a minute");
  const text = await askAnthropic(apiKey, { max_tokens: 6000, messages: [{ role: "user", content }] });
  if (!text) throw new Error("The model did not return an answer for the page.");
  return parsePageAnswer(text);
}

// ---------- Stomp a model: build a finished trap task ----------
// The model is the task author here. It must hand back a task that is ready to use,
// not advice about what a good task would contain.
export type StompTask = {
  blindSpot: string;
  imagePrompt: string;
  question: string;
  correctAnswer: string;
  justification: string;
  steps: string[];
  distractors: { answer: string; error: string }[];
  whyItWorks: string;
  verify: string[];
  failurePoints: string[]; // other specific failure points the AI suggests for this niche
};

const STOMP_RULES = `You are the task author. Your job is to write ONE finished task that makes a general vision model answer wrongly about a scientific image.
Do the work yourself. Write the actual task, not a description of what a good task would contain.

Hard rules:
- No placeholders and no meta language. Phrases like "a subtle detail", "the key cue", "depends on the image", "a plausible but incorrect interpretation" are failures. Name the actual compound, structure, value, label, colour, position or count.
- Decide the image first and fix every detail that matters. Everything else must follow from that one image.
- The correct answer is a definite answer (a name, a value, a choice) that is true of the image exactly as you described it. Never say the answer depends on anything.
- The science must be correct and checkable. Do not invent facts.
- Do not make the task easier to pass than the guidelines allow, and do not hide a guideline violation.
- Hard does not mean unfair: the image must contain everything needed, and an expert looking carefully must reach the correct answer with certainty.

Difficulty. A strong, careful vision model must still get this wrong:
- Never use a textbook example or a famous figure. Models have memorised those and answer from memory.
- The trap must hinge on PERCEPTION, not on a rule. A strong model recites any rule correctly, so a puzzle that is solved once the labels are read (a stereodescriptor, a named reaction, a formula) is too easy. The answer must depend on something that can only be read off the picture itself: a count, a position, a reading between scale marks, which line connects to which label, a small glyph, a relative size.
- Make that perceptual reading genuinely hard: dense, crowded or near-identical elements, crossings, a value that falls between unlabelled marks, a label placed nearer to the wrong object than to its own.
- Counter-prior design: set the image up so the answer a model expects from the overall look of the scene is wrong, and only the specific evidence gives the right one.
- The right answer must need at least two dependent readings of the image (for example a small label AND a spatial relation, or a scale reading AND a unit), so that one careless reading is enough to fail.
- The decisive detail must be small or ordinary-looking, placed away from the visual centre, and never emphasised. A larger, more eye-catching feature must point to a wrong answer.
- Where numbers are involved, make the wrong readings land on round, plausible values and the right one on a less tidy value.
- Before you finish, answer the question yourself the way a fast, confident model would. If that model would get it right, the task is too easy: add a second dependent detail or a stronger counter-prior and try again. Only return a task you expect to be failed.

Known blind spots of vision models. Build the trap and every distractor from these:
- miscounting similar or partly overlapping items; off-by-one on dense groups
- left/right, clockwise/anticlockwise and mirror-image confusion; ignoring rotation or viewing direction
- reading a scale between graduations, uneven or logarithmic axes, an offset zero, or the wrong unit
- small text: subscripts, superscripts, charges, minus signs, primes, decimal points, similar glyphs (l/1/I, O/0)
- following one line through crossings, tangles or a legend; attaching a label to the nearest object instead of the one its leader line points to
- judging relative length, area or angle by eye; perspective and occlusion
- near-identical colours or patterns; trusting a legend that is in a different order from the plot
- answering from the caption, title or typical case instead of what is drawn
- ignoring a convention that reverses the reading (projection rules, sign conventions, inverted axes, time order)

How to build it:
1. blind_spot: if one is given below, sharpen it into one precise sentence. If none is given, choose from the list above the blind spots that fit this niche and state precisely how this task uses them. Use at least two together.
2. image_prompt: the full description of the image, which will be drawn as a clean scientific diagram (line art, labelled, not a photograph) unless a source image is attached. State what is shown, the layout, every label, number and unit that appears, colours, and the decisive details and exactly where they sit. State what must NOT appear (no caption or text that gives the answer away). 110 to 190 words, written as a direct instruction to the illustrator.
3. question: the single question put to the model. It must look routine and must not hint that there is a trick. It must only be answerable correctly by reading the decisive details.
4. correct_answer and justification: the answer, then one or two sentences citing the exact details in the image that prove it.
5. steps: the atomic reasoning steps from the image to the answer.
6. distractors: exactly five wrong answers, each close to the right one and hard to tell apart from it. Each must be the exact answer produced by applying ONE named blind spot from the list to THIS image, with the misreading spelled out step by step in "error". Rules for the set:
   - the first is the answer a confident model gives from the overall look of the image;
   - at least two are near-misses that get every step right except one;
   - at least one combines two misreadings;
   - none is absurd, off-topic, a different kind of answer, or a refusal such as "cannot be determined";
   - all five are the same form and length as the correct answer, so nothing about its shape gives it away.
7. why_it_works: the specific wrong reading the model is most likely to make, which distractor it leads to, and why the image invites it.
8. verify: the exact details that must be visible in the rendered image for the answer to hold.
9. suggested_failure_points: four OTHER specific failure points in this niche that would make good traps, each a short phrase naming the actual thing misread.

You may draft and self-test first inside <work>...</work>, kept under 400 words. After it, output the final task as ONE JSON object and nothing else, in this shape:
{"blind_spot":"","image_prompt":"","question":"","correct_answer":"","justification":"","steps":[""],"distractors":[{"answer":"","error":""}],"why_it_works":"","verify":[""],"suggested_failure_points":[""]}`;

const GENERIC = /depends on (the|a) (subtle|image|detail)|plausible but incorrect|key (scientific|anatomical) (cue|signal)|subtle but diagnostically/i;

function parseStomp(text: string): StompTask {
  // the task is the JSON object after any <work> notes
  const body = String(text).replace(/<work>[\s\S]*?<\/work>/gi, "");
  const start = body.lastIndexOf('{"blind_spot"');
  const match = (start >= 0 ? body.slice(start) : body).match(/\{[\s\S]*\}/);
  const raw = match ? asJson(match[0]) : null;
  if (!raw) throw new Error(`The task came back in a form that could not be read. Reply was: ${String(text).slice(0, 200) || "(empty)"}`);
  const str = (v: any) => String(v ?? "").trim();
  const list = (v: any) => (Array.isArray(v) ? v : []);
  const task: StompTask = {
    blindSpot: str(raw.blind_spot),
    imagePrompt: str(raw.image_prompt),
    question: str(raw.question),
    correctAnswer: str(raw.correct_answer),
    justification: str(raw.justification),
    steps: list(raw.steps).map(str).filter(Boolean),
    distractors: list(raw.distractors).map((d: any) => (typeof d === "string" ? { answer: str(d), error: "" } : { answer: str(d?.answer), error: str(d?.error) })).filter((d: { answer: string }) => d.answer),
    whyItWorks: str(raw.why_it_works),
    verify: list(raw.verify).map(str).filter(Boolean),
    failurePoints: list(raw.suggested_failure_points).map(str).filter(Boolean).slice(0, 6),
  };
  if (!task.imagePrompt || !task.question || !task.correctAnswer) throw new Error("The task came back incomplete. Try again.");
  if (GENERIC.test(`${task.imagePrompt} ${task.correctAnswer} ${task.distractors.map((d) => d.answer).join(" ")}`)) {
    throw new Error("The task came back as a generic template instead of a finished task. Try again, or name a more specific blind spot.");
  }
  return task;
}

// The complete brief as it is handed to the model under test: question plus answer options, no answer.
export function modelBrief(t: StompTask): string {
  return `${t.question}\n\n(Attach the trap image.)`;
}

export function stompText(t: StompTask, source?: SourceRef | null): string {
  return [
    "LUMIERE STUDIO ADVERSARIAL TEST",
    `BLIND SPOT\n${t.blindSpot}`,
    `BLIND-SPOT QUESTION\n${t.question}`,
    `IMAGE PROMPT\n${t.imagePrompt}`,
    source ? `SOURCE IMAGE\n${source.title}\n${source.page || source.url}\nLicence: ${source.license} · ${source.source}` : "",
    `EXPECTED SOLUTION\n${t.correctAnswer}${t.justification ? `\n${t.justification}` : ""}`,
    t.steps.length ? `STEPS\n${t.steps.map((s, i) => `${i + 1}. ${s}`).join("\n")}` : "",
    `DISTRACTORS\n${t.distractors.map((d, i) => `${i + 1}. ${d.answer}${d.error ? ` (${d.error})` : ""}`).join("\n")}`,
    `WHY THIS TRAP WORKS\n${t.whyItWorks}`,
    t.verify.length ? `MUST BE VISIBLE IN THE IMAGE\n${t.verify.map((v) => `- ${v}`).join("\n")}` : "",
  ].filter(Boolean).join("\n\n");
}

export type SourceRef = { title: string; url: string; page: string; source: string; license: string };
// `harder` carries a previous attempt that a model solved, so the next one closes that route.
export type StompBrief = {
  niche: string; subdomain?: string; trapType: string; blindSpot: string; source?: SourceRef | null; harder?: { question: string; solvedBy: string } | null;
  rendered?: boolean; // the image will be made by an image AI, so it can be a realistic scene
};

// Builds a finished trap task. The guide is optional; when given, the task must also pass its checks.
// When a source image is supplied, the task is built on that exact image.
export async function stompTask(apiKey: string, guidelines: GuidelineSource | null, brief: StompBrief, sourceImage?: string | null): Promise<StompTask> {
  beginJob();
  const ask = [
    STOMP_RULES, "",
    `NICHE: ${brief.niche}`,
    brief.subdomain ? `SUB-DOMAIN: ${brief.subdomain}. The image and the question must sit squarely inside this sub-domain and use its real conventions, instruments and notation.` : "",
    brief.trapType ? `TRAP TYPE: ${brief.trapType}. Make this the primary design of the trap.` : "",
    `BLIND SPOT: ${brief.blindSpot || "(none given: choose one yourself)"}`,
    sourceImage && brief.source
      ? `A SOURCE IMAGE is attached ("${brief.source.title}", ${brief.source.source}, licence ${brief.source.license}). Build the task on this exact image. The question and the correct answer must be true of what is actually visible in it. image_prompt must be an accurate description of this image, not a new invention. Look at it closely before you write anything.`
      : brief.source ? `Use this open-source image as the visual anchor: "${brief.source.title}" (${brief.source.page || brief.source.url}).` : "",
    brief.rendered && !sourceImage
      ? `IMAGE STYLE: the image will be rendered by a high-quality image generator, not drawn as line art. This replaces the "clean scientific diagram" part of instruction 2. Describe a realistic scientific scene (a bench photograph, an instrument display, a micrograph, a gel, a printed chart on a desk) and use that realism to make the trap harder: natural clutter, a second similar object nearby, a reflection or partial occlusion, perspective, and an eye-catching feature that points to the wrong answer. Still fix every decisive detail exactly: put any text that must appear in double quotes, give counts as numbers, and say where each decisive element sits in the frame. Keep the decisive elements few and countable, because the generator cannot be trusted with fine numeric scales.`
      : "",
    guidelines ? "The task must also pass every check in the PROJECT GUIDELINES." : "",
    brief.harder
      ? `PREVIOUS ATTEMPT, TOO EASY. A model answered this correctly:\nQuestion: ${brief.harder.question}\nHow it solved it: ${brief.harder.solvedBy}\nWrite a NEW task that this reasoning does not solve. Change the subject of the image, stack more dependent readings, and strengthen the counter-prior. Do not reuse the previous image or question.`
      : "",
  ].filter((l) => l !== "").join("\n");
  const content: Block[] = [
    ...(guidelines ? guidelineBlocks(guidelines) : []),
    ...(sourceImage ? [imageBlock(sourceImage)] : []),
    { type: "text", text: ask },
  ];
  return parseStomp(await askAnthropic(apiKey, { max_tokens: 12000, messages: [{ role: "user", content }] }));
}

// The prompt handed to an image AI: the scene, plus what must and must not be in it.
export function renderPrompt(t: StompTask): string {
  return [
    t.imagePrompt,
    t.verify.length ? `These details must be clearly present: ${t.verify.join("; ")}.` : "",
    "Photorealistic, sharp focus, natural lighting. Do not add any title, caption, watermark, arrow, highlight or text that is not described above.",
  ].filter(Boolean).join("\n");
}

// Image generators never follow a prompt exactly. After the image exists, Claude looks at it
// and rewrites the task so the answer is true of the picture that was actually made.
export async function groundTask(apiKey: string, guidelines: GuidelineSource | null, draft: StompTask, imageBase64: string): Promise<StompTask> {
  beginJob();
  const ask = [
    STOMP_RULES, "",
    "AN IMAGE IS ATTACHED. It was generated from the image prompt of the draft task below, and it will differ from that prompt in places.",
    "Look at it closely: count things, read every piece of text, note positions. Then write the final task so that the question, correct answer, steps, distractors, why_it_works and verify are all true of THIS image exactly as it is.",
    "Keep the draft's blind spot if the image still supports it. If it does not, use the strongest perceptual trap the image does support. Use real quirks of the image (crowding, occlusion, look-alike objects, small text) to make the distractors harder.",
    "Keep image_prompt as in the draft.",
    'If the image shows the answer in plain text, or is too garbled to support any sound question, return the draft unchanged but start why_it_works with "IMAGE UNUSABLE: " and the reason.',
    guidelines ? "The task must also pass every check in the PROJECT GUIDELINES." : "",
    "\nDRAFT TASK:", stompText(draft),
  ].filter(Boolean).join("\n");
  const content: Block[] = [...(guidelines ? guidelineBlocks(guidelines) : []), imageBlock(imageBase64), { type: "text", text: ask }];
  const final = parseStomp(await askAnthropic(apiKey, { max_tokens: 12000, messages: [{ role: "user", content }] }));
  return { ...final, imagePrompt: draft.imagePrompt };
}

// ---------- Trap test: does a model actually fall for it? ----------
export type TrapTest = { answer: string; reasoning: string; held: boolean; verdict: string };

// A fresh model answers the question from the image alone, then a second call marks it.
// "held" means the model got it wrong, which is what a good trap does.
export async function testTrap(apiKey: string, task: StompTask, image: { base64?: string | null; svg?: string | null }): Promise<TrapTest> {
  beginJob();
  const solve: Block[] = [
    ...(image.base64 ? [imageBlock(image.base64)] : []),
    {
      type: "text",
      text: [
        image.svg ? `The image is given as SVG markup:\n${image.svg.slice(0, 30000)}\n` : "",
        task.question,
        "\nAnswer the question about the image. Give your final answer on the first line, then your reasoning in two or three sentences.",
      ].filter(Boolean).join("\n"),
    },
  ];
  const reply = await askAnthropic(apiKey, { max_tokens: 5000, messages: [{ role: "user", content: solve }] });
  if (!reply) throw new Error("The test model returned no answer. Try again.");
  const marking = await askAnthropic(apiKey, {
    max_tokens: 2000,
    messages: [{ role: "user", content: [{ type: "text", text: `Mark an answer. Reply with ONLY JSON: {"correct":true|false,"why":"one sentence"}.\nQuestion: ${task.question}\nCorrect answer: ${task.correctAnswer}. ${task.justification}\nAnswer given:\n${reply.slice(0, 1500)}\nIt is correct only if its final answer means the same as the correct answer.` }] }],
  });
  const mark = asJson(marking.match(/\{[\s\S]*\}/)?.[0] ?? "");
  if (typeof mark?.correct !== "boolean") throw new Error("The test could not be marked. Try again.");
  const [first, ...rest] = reply.trim().split("\n");
  return { answer: first.trim(), reasoning: rest.join("\n").trim(), held: !mark.correct, verdict: String(mark.why ?? "").trim() };
}

// ---------- Playbook review: a strict second look at a finished task ----------
export type ReviewItem = { check: string; pass: boolean; note: string };

const REVIEW_RULES = `You are reviewing a finished trap task against the Lumiere playbook. Be strict. Do not pass a check by default.
Return one entry for each of these checks, in this order:
1. "GTFA": there is exactly one verifiable final answer, in a definite form.
2. "Atomic steps": every solution step is a single inference and the steps reach the answer.
3. "Distraction quality": there are five distractors, each specific and tied to a real error.
4. "Image description is not revealing": the image prompt contains no text, caption or emphasis that gives the answer away.
5. "Source and licence check": the image source and licence are stated and usable, or the image is original.
6. "Failure mode is justified": the stated reason a model would fail is specific and believable.
7. "Image matches the answer": if an image is supplied (as a picture or as SVG markup), every MUST-BE-VISIBLE detail is really there and the correct answer is true of it. If no image is supplied, fail this check with the note "No image to check yet".
Also check the science: if the correct answer is wrong, fail "GTFA" and say what the right answer is.
For each check give pass true or false and one sentence that names the exact problem or the exact evidence.
Respond with ONLY a JSON object: {"checks":[{"check":"","pass":true,"note":""}]}`;

export async function reviewTask(
  apiKey: string, task: StompTask, guidelines: GuidelineSource | null,
  image?: { base64?: string | null; svg?: string | null }, source?: SourceRef | null,
): Promise<ReviewItem[]> {
  beginJob();
  const text = [
    REVIEW_RULES, "",
    "THE TASK:", stompText(task, source), "",
    image?.svg ? `THE IMAGE (SVG markup):\n${image.svg.slice(0, 30000)}` : image?.base64 ? "THE IMAGE is attached." : "No image is supplied.",
    guidelines ? "Also apply every check in the PROJECT GUIDELINES and fail the closest entry above when one is broken." : "",
  ].filter(Boolean).join("\n");
  const content: Block[] = [
    ...(guidelines ? guidelineBlocks(guidelines) : []),
    ...(image?.base64 ? [imageBlock(image.base64)] : []),
    { type: "text", text },
  ];
  const reply = await askAnthropic(apiKey, { max_tokens: 5000, messages: [{ role: "user", content }] });
  const raw = asJson(reply.match(/\{[\s\S]*\}/)?.[0] ?? "");
  const checks = Array.isArray(raw?.checks) ? raw.checks : [];
  if (checks.length === 0) throw new Error("The review came back in a form that could not be read. Try again.");
  return checks.map((c: any) => ({ check: String(c?.check ?? "Check"), pass: c?.pass === true, note: String(c?.note ?? "").trim() }));
}

// ---------- Trap image ----------
// Claude cannot produce photos, so the image is drawn as an SVG diagram and rendered on the phone.
const DRAW_RULES = `Draw the image described below as ONE self-contained SVG.

Output rules:
- First write a short <work>...</work> block: for every scale, the one linear formula you will use (pixel = origin + k × value), then each stated value with its pixel coordinate.
- After it, output the SVG markup, starting with <svg and ending with </svg>. No markdown fence, no other commentary.
- Use xmlns="http://www.w3.org/2000/svg" and viewBox="0 0 1024 1024". Start with an opaque white background rectangle.
- Use only rect, circle, ellipse, line, polyline, polygon, path, text, tspan, g, defs and linearGradient, styled with presentation attributes.
- Do not use <style>, CSS classes, <image>, <foreignObject>, filters, masks, scripts, animations or any external reference.
- Text: font-family="sans-serif", font-size 24 or larger, dark on light, fully inside the canvas, never overlapping other text or shapes.

Drawing rules:
- Draw exactly what the description says. Add no trick, distortion or extra feature of your own: the trap is already in the description.
- Every scale, ruler and axis is strictly linear and evenly spaced unless the description says otherwise. Place every tick, label, line and object with the formula from your work block, so a value read off the drawing equals the value in the description.
- Render every label, number and unit exactly as written in the description. Do not add, drop or round any.
- Draw the science correctly: bond geometry, wedge and dash bonds, glassware shapes, scale graduations and axis ticks must be accurate and evenly spaced.
- The decisive detail must be accurate and legible at phone size, but no more prominent than the description says. Do not highlight it.
- Never write the question, the answer, a title or a caption that gives the answer away.
- The finished image must make the CORRECT ANSWER below true. It is for your reference only and must not appear in the image.`;

function cleanSvg(text: string): string {
  const match = String(text).match(/<svg[\s\S]*<\/svg>/i);
  if (!match) throw new Error("The image could not be drawn. Try Redraw.");
  let svg = match[0]
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, "")
    .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*')/gi, "");
  if (!/xmlns=/.test(svg)) svg = svg.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
  return svg;
}

const CHECK_RULES = `Check an SVG drawing against its specification by computing from the coordinates in the markup. Do not trust appearances.
For every scale, ruler or axis: confirm the tick labels are evenly spaced and work out the value each relevant object sits at.
Confirm every stated label, number, position and count, every MUST BE VISIBLE item, and that the CORRECT ANSWER is true of the drawing as drawn.
Confirm nothing in the drawing states or gives away the answer.
Respond with ONLY JSON: {"ok":true|false,"problems":["one specific problem per entry, with the value found and the value expected"]}`;

export type TrapDrawing = { svg: string; problems: string[] };

// Draws the image, then checks the drawing against the task and redraws once if it is wrong.
// Any problems that remain are returned so the screen can warn about them.
export async function drawTrapImage(apiKey: string, task: StompTask, onProgress?: (stage: string) => void): Promise<TrapDrawing> {
  beginJob();
  const spec = [
    `IMAGE DESCRIPTION:\n${task.imagePrompt}`,
    task.verify.length ? `MUST BE VISIBLE:\n${task.verify.map((v) => `- ${v}`).join("\n")}` : "",
    `QUESTION (reference only): ${task.question}`,
    `CORRECT ANSWER (reference only): ${task.correctAnswer}. ${task.justification}`,
  ].filter(Boolean).join("\n\n");
  const ask = (text: string, max_tokens: number) => askAnthropic(apiKey, { max_tokens, messages: [{ role: "user", content: [{ type: "text", text }] }] });
  const check = async (svg: string): Promise<string[]> => {
    const raw = asJson((await ask(`${CHECK_RULES}\n\n${spec}\n\nSVG:\n${svg.slice(0, 40000)}`, 4000)).match(/\{[\s\S]*\}/)?.[0] ?? "");
    if (typeof raw?.ok !== "boolean") return ["The drawing could not be checked automatically. Check it by eye."];
    return raw.ok ? [] : (Array.isArray(raw.problems) ? raw.problems.map(String).filter(Boolean) : ["The checker found a mismatch but gave no detail."]);
  };

  let svg = cleanSvg(await ask(`${DRAW_RULES}\n\n${spec}`, 16000));
  onProgress?.("Checking the drawing against the answer…");
  let problems = await check(svg);
  if (problems.length > 0) {
    onProgress?.("Fixing the drawing…");
    svg = cleanSvg(await ask(`${DRAW_RULES}\n\n${spec}\n\nYour previous drawing was wrong. Fix every one of these problems and draw it again from scratch:\n${problems.map((x) => `- ${x}`).join("\n")}`, 16000));
    onProgress?.("Checking the drawing again…");
    problems = await check(svg);
  }
  return { svg, problems };
}
