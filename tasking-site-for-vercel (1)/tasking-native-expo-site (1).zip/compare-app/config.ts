// Server that holds the access codes (Supabase). The publishable key is safe to ship in the app:
// it can only call the access functions, which do their own checks. Never put the secret key here.
export const SUPABASE_URL = "https://lfdlhgfahtknkzgezldv.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_A5dYhVJLUFd-sXqni6QpRg_EHnG95ha";

// How long the app keeps working without reaching the server (plane, no signal).
export const OFFLINE_GRACE_DAYS = 3;
