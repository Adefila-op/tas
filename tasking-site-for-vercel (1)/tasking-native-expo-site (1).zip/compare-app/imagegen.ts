// Optional second AI used only to render the trap image. Claude still writes the task.
// The user supplies their own key for the provider in Settings.
import * as FileSystem from "expo-file-system/legacy";
import * as SecureStore from "expo-secure-store";

export type ImageProvider = "openai" | "gemini";
export type ImageAi = { provider: ImageProvider; key: string; model: string };

export const PROVIDERS: { id: ImageProvider; label: string; defaultModel: string; keyHint: string }[] = [
  { id: "openai", label: "OpenAI", defaultModel: "gpt-image-2", keyHint: "sk-…" },
  { id: "gemini", label: "Google Gemini", defaultModel: "gemini-3.1-flash-image", keyHint: "AIza…" },
];
export const providerInfo = (id: ImageProvider) => PROVIDERS.find((p) => p.id === id) ?? PROVIDERS[0];

const STORE = "image_ai_settings";

export async function loadImageAi(): Promise<ImageAi | null> {
  try {
    const raw = await SecureStore.getItemAsync(STORE);
    const v = raw ? JSON.parse(raw) : null;
    return v?.key ? { provider: v.provider === "gemini" ? "gemini" : "openai", key: String(v.key), model: String(v.model || "") } : null;
  } catch {
    return null;
  }
}

export async function saveImageAi(v: ImageAi | null): Promise<void> {
  if (!v || !v.key.trim()) { await SecureStore.deleteItemAsync(STORE).catch(() => {}); return; }
  await SecureStore.setItemAsync(STORE, JSON.stringify({ provider: v.provider, key: v.key.trim(), model: v.model.trim() }));
}

async function post(url: string, headers: Record<string, string>, body: unknown): Promise<{ status: number; data: any }> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 180_000);
  try {
    const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json", ...headers }, body: JSON.stringify(body), signal: ctl.signal });
    const text = await res.text();
    let data: any = null;
    try { data = JSON.parse(text); } catch { /* not JSON */ }
    return { status: res.status, data };
  } catch (e: any) {
    if (e?.name === "AbortError") throw new Error("The image AI took longer than 3 minutes. Try again.");
    throw new Error("Could not reach the image AI. Check your internet connection.");
  } finally {
    clearTimeout(timer);
  }
}

function fail(provider: string, status: number, data: any): never {
  const msg = data?.error?.message || data?.error || "";
  if (status === 401 || status === 403) throw new Error(`${provider} rejected the image key. Check it in Settings.`);
  if (status === 404) throw new Error(`${provider} does not know that image model. Check the model name in Settings.`);
  if (status === 429) throw new Error(`${provider} is rate-limiting or out of credit. ${typeof msg === "string" ? msg : ""}`.trim());
  throw new Error(`${provider} image request failed (${status}). ${typeof msg === "string" ? msg.slice(0, 200) : ""}`.trim());
}

async function saveBase64(b64: string, ext: string): Promise<string> {
  const uri = `${FileSystem.cacheDirectory}lumiere-ai-${Date.now()}.${ext}`;
  await FileSystem.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
  return uri;
}

async function openai(ai: ImageAi, prompt: string): Promise<string> {
  const { status, data } = await post("https://api.openai.com/v1/images/generations", { authorization: `Bearer ${ai.key}` }, {
    model: ai.model || providerInfo("openai").defaultModel, prompt, size: "1024x1024", n: 1,
  });
  if (status !== 200) fail("OpenAI", status, data);
  const first = data?.data?.[0];
  if (first?.b64_json) return saveBase64(first.b64_json, "png");
  if (first?.url) {
    const out = await FileSystem.downloadAsync(first.url, `${FileSystem.cacheDirectory}lumiere-ai-${Date.now()}.png`);
    if (out.status === 200) return out.uri;
  }
  throw new Error("OpenAI returned no image. Try again.");
}

async function gemini(ai: ImageAi, prompt: string): Promise<string> {
  const model = ai.model || providerInfo("gemini").defaultModel;
  const body = { contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseModalities: ["TEXT", "IMAGE"] } };
  let res = await post(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, { "x-goog-api-key": ai.key }, body);
  if (res.status === 404) res = await post(`https://generativelanguage.googleapis.com/v1/models/${encodeURIComponent(model)}:generateContent`, { "x-goog-api-key": ai.key }, body);
  if (res.status !== 200) fail("Gemini", res.status, res.data);
  const parts: any[] = res.data?.candidates?.[0]?.content?.parts ?? [];
  const img = parts.map((p) => p.inlineData ?? p.inline_data).find((d) => d?.data);
  if (!img) throw new Error("Gemini returned no image. It may have declined the prompt; try again or rephrase the blind spot.");
  return saveBase64(img.data, /jpe?g/.test(img.mimeType ?? img.mime_type ?? "") ? "jpg" : "png");
}

// Renders the prompt and returns a local file.
export async function generateImage(ai: ImageAi, prompt: string): Promise<string> {
  return ai.provider === "gemini" ? gemini(ai, prompt) : openai(ai, prompt);
}
