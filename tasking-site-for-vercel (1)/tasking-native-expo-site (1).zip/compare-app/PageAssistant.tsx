// Page assistant: photograph or pick a screenshot of a task page and the AI answers the question on it.
import * as ImagePicker from "expo-image-picker";
import { useEffect, useState } from "react";
import { Alert, Image, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { analyzePage, PageAnswer } from "./compare";
import type { Job } from "./LumiereStudio";
import { readText } from "./ocr";
import { loadGuidelines, Project } from "./projects";
import { Button, C, Card, Chips, Empty, T } from "./ui";

type State = { uri: string; ocr: string; question: string; guideId: string; result: PageAnswer | null };
const fresh: State = { uri: "", ocr: "", question: "", guideId: "", result: null };
let remembered: State = fresh;

export default function PageAssistant({ apiKey, projects, job }: { apiKey: string; projects: Project[]; job: Job }) {
  const [s, setS] = useState<State>(remembered);
  const set = (patch: Partial<State>) => setS((cur) => ({ ...cur, ...patch }));
  useEffect(() => { remembered = s; }, [s]);
  const guide = projects.find((p) => p.id === s.guideId) ?? null;

  const usePage = async (uri: string) => {
    set({ uri, ocr: "", result: null });
    const ocr = await readText(uri); // empty when text recognition isn't available in this build
    setS((cur) => (cur.uri === uri ? { ...cur, ocr } : cur));
  };

  const snap = async () => {
    const cam = await ImagePicker.requestCameraPermissionsAsync();
    if (!cam.granted) return Alert.alert("Permission needed", "Allow camera access so the app can capture the page.");
    const res = await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], quality: 0.8 });
    if (!res.canceled && res.assets?.[0]) await usePage(res.assets[0].uri);
  };

  const pick = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return Alert.alert("Permission needed", "Allow photo access to pick a webpage screenshot.");
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 1 });
    if (!res.canceled && res.assets?.[0]) await usePage(res.assets[0].uri);
  };

  const analyze = async () => {
    const result = await job("Analyzing the page…", async (setStage) => {
      const guidelines = guide ? await loadGuidelines(guide) : null;
      return analyzePage(apiKey, s.uri, s.ocr, s.question, guidelines, setStage);
    });
    if (result) set({ result });
  };

  const { result } = s;
  return (
    <>
      <View style={T.row}>
        <Button title="Snap page" onPress={snap} small />
        <Button title="From library" kind="ghost" onPress={pick} small />
      </View>

      {!s.uri ? (
        <Empty title="No page captured" hint="Snap the page with the camera, or choose a screenshot from your library." />
      ) : (
        <Card>
          <Text style={T.section}>Captured page</Text>
          <Image source={{ uri: s.uri }} style={styles.page} resizeMode="contain" />
          {!!s.ocr && (
            <>
              <Text style={T.section}>Text read from the page</Text>
              <Text selectable style={T.muted} numberOfLines={8}>{s.ocr}</Text>
            </>
          )}
        </Card>
      )}

      <Text style={T.section}>Question (optional)</Text>
      <TextInput
        style={T.input} multiline placeholderTextColor={C.faint} value={s.question} onChangeText={(v) => set({ question: v })}
        placeholder="Leave blank and the app finds the question on the page. Or ask your own, e.g. Which response best meets the visible rubric?"
      />

      {projects.length > 0 && (
        <>
          <Text style={T.section}>Guide (optional)</Text>
          <Chips options={projects.map((p) => p.name)} value={guide?.name ?? ""} onPick={(v) => set({ guideId: projects.find((p) => p.name === v)?.id ?? "" })} />
        </>
      )}

      <Button title="Analyze page" onPress={analyze} disabled={!s.uri} />

      {result && (
        <>
          <Card>
            <Text style={T.section}>Answer</Text>
            <Text selectable style={T.body}>{result.answer || "No answer was returned."}</Text>
            <Button title="Share answer" kind="ghost" small onPress={() => Share.share({ message: result.answer }).catch(() => {})} />
          </Card>
          {!!result.detectedQuestion && (
            <Card>
              <Text style={T.section}>Detected question</Text>
              <Text selectable style={T.body}>{result.detectedQuestion}</Text>
            </Card>
          )}
          {!!result.extractedText && (
            <Card>
              <Text style={T.section}>Extracted page text</Text>
              <Text selectable style={T.muted}>{result.extractedText}</Text>
            </Card>
          )}
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  page: { width: "100%", height: 280, borderRadius: 8, backgroundColor: "#111" },
});
