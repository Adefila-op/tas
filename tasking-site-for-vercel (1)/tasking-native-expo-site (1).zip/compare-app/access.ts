// Access codes. A code is issued in the admin panel, checked by the server, and tied to this phone.
// The app is locked until the server confirms the code, and it re-checks every time it opens.
import * as SecureStore from "expo-secure-store";
import { OFFLINE_GRACE_DAYS, SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from "./config";

const DEVICE_KEY = "tasking_device_id";
const ACCESS_KEY = "tasking_access_code";

export type Access = { code: string; deviceId: string; expiresAt: string; checkedAt: string };
export type Gate = { open: true; access: Access; offline: boolean } | { open: false; message: string };

export async function getOrCreateDeviceId(): Promise<string> {
  const saved = await SecureStore.getItemAsync(DEVICE_KEY).catch(() => null);
  if (saved) return saved;
  const id = `mobile-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  await SecureStore.setItemAsync(DEVICE_KEY, id).catch(() => {});
  return id;
}

const REASONS: Record<string, string> = {
  invalid: "That code isn't recognised. Check it and try again.",
  revoked: "This code has been switched off. Contact whoever gave it to you.",
  expired: "This code has expired. Ask for a new one or a renewal.",
  device_limit: "This code is already in use on another phone. Ask for its devices to be reset.",
  too_many: "Too many wrong codes. Wait 10 minutes and try again.",
  not_activated: "This phone is no longer linked to the code. Enter the code again.",
  bad_device: "This phone could not be identified. Restart the app and try again.",
};
const reasonText = (r: unknown) => REASONS[String(r)] ?? "The code could not be confirmed. Try again.";

class Unreachable extends Error {}

async function rpc(fn: string, body: Record<string, unknown>): Promise<any> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15_000);
  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
      method: "POST",
      headers: { "content-type": "application/json", apikey: SUPABASE_PUBLISHABLE_KEY, authorization: `Bearer ${SUPABASE_PUBLISHABLE_KEY}` },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    if (!res.ok) throw new Unreachable(`The access server answered ${res.status}.`);
    return await res.json();
  } catch (e) {
    if (e instanceof Unreachable) throw e;
    throw new Unreachable("Could not reach the access server. Check your internet connection.");
  } finally {
    clearTimeout(timer);
  }
}

async function loadAccess(): Promise<Access | null> {
  try {
    const raw = await SecureStore.getItemAsync(ACCESS_KEY);
    const v = raw ? JSON.parse(raw) : null;
    return v?.code && v?.expiresAt ? (v as Access) : null;
  } catch {
    return null;
  }
}

const save = (a: Access) => SecureStore.setItemAsync(ACCESS_KEY, JSON.stringify(a)).catch(() => {});

export async function clearAccess(): Promise<void> {
  await SecureStore.deleteItemAsync(ACCESS_KEY).catch(() => {});
}

// Sends the code to the server. Throws a readable message when it is refused.
export async function activateAccess(raw: string): Promise<Access> {
  const code = raw.trim().toUpperCase().replace(/\s+/g, "");
  if (!code) throw new Error("Enter your access code.");
  const deviceId = await getOrCreateDeviceId();
  const r = await rpc("activate_code", { p_code: code, p_device: deviceId });
  if (!r?.ok) throw new Error(reasonText(r?.reason));
  const access: Access = { code, deviceId, expiresAt: String(r.expires_at), checkedAt: new Date().toISOString() };
  await save(access);
  return access;
}

// Decides whether the app may open. Runs at launch and whenever the app comes back to the front.
export async function checkGate(): Promise<Gate> {
  const access = await loadAccess();
  if (!access) return { open: false, message: "" };
  try {
    const r = await rpc("check_access", { p_code: access.code, p_device: access.deviceId });
    if (!r?.ok) {
      await clearAccess();
      return { open: false, message: reasonText(r?.reason) };
    }
    const fresh: Access = { ...access, expiresAt: String(r.expires_at), checkedAt: new Date().toISOString() };
    await save(fresh);
    return { open: true, access: fresh, offline: false };
  } catch {
    // No connection: keep working for a few days, but never past the code's own expiry.
    const now = Date.now();
    const withinGrace = now - Date.parse(access.checkedAt) < OFFLINE_GRACE_DAYS * 86_400_000;
    if (withinGrace && now < Date.parse(access.expiresAt)) return { open: true, access, offline: true };
    return { open: false, message: "Connect to the internet so the app can confirm your access code." };
  }
}

export const daysLeft = (a: Access) => Math.max(0, Math.ceil((Date.parse(a.expiresAt) - Date.now()) / 86_400_000));
