// Guideline projects: a PDF, a text file, or a set of photographed pages.
// Files live in the app's document directory; a small JSON index lists them.
// The index stores file names only: the directory's absolute path can change
// when the app is updated, so full paths are rebuilt on every read.
import * as FileSystem from "expo-file-system/legacy";
import { toJpegBase64 } from "./media";

export type Project = {
  id: string;
  name: string;
  kind: "pdf" | "text" | "images";
  path: string;        // file name of the pdf or text file; for images, the first page
  paths?: string[];    // page file names for kind "images"
  addedAt: number;
};

export type GuidelineSource =
  | { kind: "pdf"; base64: string }
  | { kind: "text"; text: string }
  | { kind: "images"; images: string[] };

const DIR = `${FileSystem.documentDirectory}guidelines/`;
const INDEX = `${DIR}index.json`;

const fileName = (p: string) => p.split("/").pop() || p;
const abs = (p: string) => `${DIR}${fileName(p)}`;

// One index change at a time, so two saves can't overwrite each other.
let queue: Promise<unknown> = Promise.resolve();
function locked<T>(fn: () => Promise<T>): Promise<T> {
  const run = queue.then(fn, fn);
  queue = run.catch(() => {});
  return run;
}

async function ensureDir() {
  const info = await FileSystem.getInfoAsync(DIR);
  if (!info.exists) await FileSystem.makeDirectoryAsync(DIR, { intermediates: true });
}

export async function listProjects(): Promise<Project[]> {
  const info = await FileSystem.getInfoAsync(INDEX).catch(() => null);
  if (!info?.exists) return [];
  try {
    const parsed = JSON.parse(await FileSystem.readAsStringAsync(INDEX));
    if (!Array.isArray(parsed)) throw new Error("not a list");
    // older versions stored absolute paths; reduce them to file names
    return parsed.map((p: Project) => ({ ...p, path: fileName(p.path), paths: p.paths?.map(fileName) }));
  } catch {
    // keep the unreadable index for recovery instead of letting the next save overwrite it
    await FileSystem.moveAsync({ from: INDEX, to: `${DIR}index.corrupt-${Date.now()}.json` }).catch(() => {});
    return [];
  }
}

async function saveIndex(projects: Project[]) {
  await ensureDir();
  await FileSystem.writeAsStringAsync(INDEX, JSON.stringify(projects));
}

const appendProject = (project: Project) => locked(async () => saveIndex([...(await listProjects()), project]));

function newId() {
  return `p${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
}

// Strips HTML to readable text so the model reads the guide's content, not its markup.
function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|h[1-6]|tr|section|article)>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n\n")
    .trim();
}

// Copies any readable URI by re-encoding through base64. copyAsync rejects some
// Android content:// URIs returned by the document and image pickers; this path works for them.
async function copyBytes(from: string, to: string) {
  const b64 = await FileSystem.readAsStringAsync(from, { encoding: FileSystem.EncodingType.Base64 });
  await FileSystem.writeAsStringAsync(to, b64, { encoding: FileSystem.EncodingType.Base64 });
}

export async function addProjectFromFile(name: string, uri: string, pickedName: string, mimeType?: string | null): Promise<Project> {
  await ensureDir();
  const id = newId();
  const lower = pickedName.toLowerCase();
  let project: Project;

  if (lower.endsWith(".pdf") || mimeType === "application/pdf") {
    const path = `${id}.pdf`;
    await copyBytes(uri, abs(path));
    project = { id, name: name || pickedName, kind: "pdf", path, addedAt: Date.now() };
  } else {
    const path = `${id}.txt`;
    const raw = await FileSystem.readAsStringAsync(uri);
    const isHtml = lower.endsWith(".html") || lower.endsWith(".htm") || mimeType === "text/html";
    const text = (isHtml ? htmlToText(raw) : raw).trim();
    if (!text) throw new Error("That file has no readable text.");
    await FileSystem.writeAsStringAsync(abs(path), text);
    project = { id, name: name || pickedName, kind: "text", path, addedAt: Date.now() };
  }

  await appendProject(project);
  return project;
}

export async function addProjectFromText(name: string, text: string): Promise<Project> {
  await ensureDir();
  const id = newId();
  const path = `${id}.txt`;
  await FileSystem.writeAsStringAsync(abs(path), text.trim());
  const project: Project = { id, name, kind: "text", path, addedAt: Date.now() };
  await appendProject(project);
  return project;
}

// Saves photographed guideline pages (in page order), shrunk to a readable JPEG.
export async function addProjectFromPhotos(name: string, uris: string[]): Promise<Project> {
  await ensureDir();
  const id = newId();
  const paths: string[] = [];
  try {
    for (let i = 0; i < uris.length; i++) {
      const path = `${id}-${i + 1}.jpg`;
      const b64 = await toJpegBase64(uris[i], 1600, 0.6);
      await FileSystem.writeAsStringAsync(abs(path), b64, { encoding: FileSystem.EncodingType.Base64 });
      paths.push(path);
    }
  } catch (e) {
    // don't leave half a guide on disk
    for (const path of paths) await FileSystem.deleteAsync(abs(path), { idempotent: true }).catch(() => {});
    throw e;
  }
  const project: Project = { id, name, kind: "images", path: paths[0], paths, addedAt: Date.now() };
  await appendProject(project);
  return project;
}

export async function deleteProject(id: string) {
  await locked(async () => {
    const projects = await listProjects();
    const target = projects.find((p) => p.id === id);
    if (target) {
      for (const path of target.paths ?? [target.path]) {
        await FileSystem.deleteAsync(abs(path), { idempotent: true }).catch(() => {});
      }
    }
    await saveIndex(projects.filter((p) => p.id !== id));
  });
}

export async function loadGuidelines(project: Project): Promise<GuidelineSource> {
  try {
    if (project.kind === "pdf") {
      return { kind: "pdf", base64: await FileSystem.readAsStringAsync(abs(project.path), { encoding: FileSystem.EncodingType.Base64 }) };
    }
    if (project.kind === "images") {
      const images: string[] = [];
      for (const path of project.paths ?? [project.path]) {
        images.push(await FileSystem.readAsStringAsync(abs(path), { encoding: FileSystem.EncodingType.Base64 }));
      }
      return { kind: "images", images };
    }
    return { kind: "text", text: await FileSystem.readAsStringAsync(abs(project.path)) };
  } catch {
    throw new Error(`The files for "${project.name}" are missing. Delete this guide and add it again.`);
  }
}
