// Lumiere Studio: a step-by-step builder where the AI writes the whole trap task,
// supplies the image, and reviews its own work against the playbook.
import * as FileSystem from "expo-file-system/legacy";
import { useEffect, useRef, useState } from "react";
import { Image, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { drawTrapImage, groundTask, renderPrompt, ReviewItem, reviewTask, StompTask, stompTask, stompText, testTrap, TrapTest } from "./compare";
import { generateImage, ImageAi, providerInfo } from "./imagegen";
import { toJpegBase64 } from "./media";
import { loadGuidelines, Project } from "./projects";
import { searchSourceImages, SourceImage } from "./sources";
import TrapImage, { TrapImageHandle } from "./TrapImage";
import { Button, C, Card, Chips, T } from "./ui";

// Runs a long action behind the app's progress card. Resolves to undefined when it fails or is cancelled.
export type Job = <R>(stage: string, fn: (setStage: (s: string) => void) => Promise<R>, opts?: { needsKey?: boolean }) => Promise<R | undefined>;

const NICHES = ["Life science", "Biology", "Chemistry", "Molecular imaging", "Cell biology"];

// Sub-domains offered for each niche. A typed niche gets a general set.
function subdomains(niche: string): string[] {
  const n = niche.toLowerCase();
  if (n.includes("chemistry")) return ["Organic", "Analytical", "Physical", "Inorganic", "Spectroscopy", "Lab technique"];
  if (n.includes("molecular")) return ["Fluorescence microscopy", "Electron microscopy", "Gels and blots", "PET / MRI", "Crystallography", "Flow cytometry"];
  if (n.includes("cell")) return ["Organelles", "Cell cycle", "Signalling", "Membrane transport", "Cytoskeleton", "Cell culture"];
  if (n.includes("biology")) return ["Anatomy", "Microbiology", "Botany", "Genetics", "Developmental biology", "Evolution"];
  if (n.includes("life")) return ["Microscopy", "Histology", "Genetics", "Physiology", "Immunology", "Ecology"];
  return ["Diagrams", "Graphs and charts", "Instruments and scales", "Lab apparatus"];
}

function trapTypes(niche: string): string[] {
  const n = niche.toLowerCase();
  if (n.includes("chemistry")) return ["reaction-order trap", "spectral-signature misread", "equilibrium-vs-rate confusion", "functional-group substitution trap"];
  if (n.includes("molecular") || n.includes("biology")) return ["cell-state misclassification", "marker-expression trap", "spatial-pattern confusion", "morphology-vs-function trap"];
  if (n.includes("cell")) return ["cell-cycle stage trap", "toxicity-vs-normality confusion", "signal-contrast trap", "morphology bias"];
  return ["salience-vs-evidence trap", "contextual-interpretation trap", "background-artifact confusion", "rare-detail detection trap"];
}

type State = {
  niche: string; subdomain: string; trapType: string; blindSpot: string; query: string;
  results: SourceImage[]; source: SourceImage | null; sourceLocal: string;
  guideId: string; realistic: boolean; task: StompTask | null; svg: string; svgProblems: string[]; photoUri: string; review: ReviewItem[]; test: TrapTest | null;
};
const fresh: State = {
  niche: "Life science", subdomain: "", trapType: "", blindSpot: "", query: "", results: [], source: null, sourceLocal: "",
  guideId: "", realistic: true, task: null, svg: "", svgProblems: [], photoUri: "", review: [], test: null,
};
// Kept between visits so a finished task isn't lost when the user opens another tab.
let remembered: State = fresh;

export default function LumiereStudio({ apiKey, imageAi, projects, job, say }: { apiKey: string; imageAi: ImageAi | null; projects: Project[]; job: Job; say: (m: string) => void }) {
  const [s, setS] = useState<State>(remembered);
  const set = (patch: Partial<State>) => setS((cur) => ({ ...cur, ...patch }));
  useEffect(() => { remembered = s; }, [s]);

  const guide = projects.find((p) => p.id === s.guideId) ?? null;
  const { task } = s;
  const shown = useRef<TrapImageHandle>(null);
  const useAi = !!imageAi && s.realistic && !s.source;

  const search = async () => {
    const found = await job("Searching open-source images…", () => searchSourceImages(s.query || defaultQuery), { needsKey: false });
    if (found) { set({ results: found }); say(`${found.length} source image${found.length === 1 ? "" : "s"} found`); }
  };

  const draw = async (t: StompTask) => {
    const drawn = await job("Drawing the image… this can take a minute", (setStage) => drawTrapImage(apiKey, t, setStage));
    if (drawn) set({ svg: drawn.svg, svgProblems: drawn.problems, photoUri: "", review: [], test: null });
  };

  // Realistic image from the user's image AI. Claude then re-reads the finished picture and
  // rewrites the answer, steps and distractors so they are true of what was actually rendered.
  const render = async (t: StompTask) => {
    if (!imageAi) return;
    const name = providerInfo(imageAi.provider).label;
    const out = await job(`Rendering the image with ${name}… this can take a minute`, async (setStage) => {
      const uri = await generateImage(imageAi, renderPrompt(t));
      setStage("Reading the finished image and fitting the task to it…");
      const guidelines = guide ? await loadGuidelines(guide) : null;
      const grounded = await groundTask(apiKey, guidelines, t, await toJpegBase64(uri, 1600, 0.9));
      return { uri, grounded };
    });
    if (out) { set({ task: out.grounded, photoUri: out.uri, svg: "", svgProblems: [], review: [], test: null }); say("Image rendered and task fitted to it"); }
  };

  const photo = async () => {
    if (!task) return;
    const uri = await job("Generating a photo-style image… this can take a minute", async () => {
      const prompt = `${task.imagePrompt.slice(0, 900)} Scientific style, high detail, clear composition.`;
      const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&seed=${Math.floor(Math.random() * 1e6)}&nologo=true`;
      const out = await FileSystem.downloadAsync(url, `${FileSystem.cacheDirectory}lumiere-trap-${Date.now()}.jpg`);
      if (out.status !== 200) throw new Error("The image generator is unavailable right now. Use the diagram instead, or try again later.");
      return out.uri;
    }, { needsKey: false });
    if (uri) set({ photoUri: uri, svg: "", review: [], test: null });
  };

  const generate = async (harder?: { question: string; solvedBy: string }) => {
    const built = await job("Building the trap… this can take a minute", async (setStage) => {
      let sourceLocal = "";
      let sourceImage: string | null = null;
      if (s.source) {
        setStage("Reading the source image…");
        try {
          const file = await FileSystem.downloadAsync(s.source.thumb || s.source.url, `${FileSystem.cacheDirectory}lumiere-source-${Date.now()}.jpg`);
          if (file.status === 200) { sourceLocal = file.uri; sourceImage = await toJpegBase64(file.uri, 1600); }
        } catch {
          // the task is still built, anchored on the source's title only
        }
      }
      setStage("Building the trap… this can take a minute");
      const guidelines = guide ? await loadGuidelines(guide) : null;
      const t = await stompTask(apiKey, guidelines, { niche: s.niche.trim(), subdomain: s.subdomain.trim(), trapType: s.trapType, blindSpot: s.blindSpot.trim(), source: s.source, harder, rendered: useAi }, sourceImage);
      return { t, sourceLocal };
    });
    if (!built) return;
    set({ task: built.t, sourceLocal: built.sourceLocal, svg: "", photoUri: "", review: [], test: null });
    say("Trap task built");
    if (built.sourceLocal) return;
    if (useAi) await render(built.t); else await draw(built.t);
  };

  // The image exactly as the model under test would get it.
  // A drawn diagram is captured from the screen as a picture, so the test model has to read pixels
  // the way the real target will. The drawing code is only used if the capture fails.
  const currentImage = async (): Promise<{ base64?: string; svg?: string } | null> => {
    const local = s.photoUri || s.sourceLocal;
    if (!s.svg) return local ? { base64: await toJpegBase64(local, 1600) } : null;
    try {
      const uri = await shown.current?.capture();
      if (uri) return { base64: await toJpegBase64(uri, 1600, 0.9) };
    } catch {
      // fall back to the drawing code below
    }
    return { svg: s.svg };
  };

  const test = async () => {
    if (!task) return;
    const result = await job("Testing the trap against a model…", async () => {
      const image = await currentImage();
      if (!image) throw new Error("Make the image first, then test the trap.");
      return testTrap(apiKey, task, image);
    });
    if (result) set({ test: result });

  };

  const review = async () => {
    if (!task) return;
    const items = await job("Reviewing against the playbook…", async () => {
      const guidelines = guide ? await loadGuidelines(guide) : null;
      return reviewTask(apiKey, task, guidelines, (await currentImage()) ?? undefined, s.sourceLocal ? s.source : null);
    });
    if (items) set({ review: items });
  };

  const share = (message: string) => Share.share({ message }).catch(() => {});
  const defaultQuery = s.subdomain.trim() ? `${s.niche} ${s.subdomain}`.trim() : `${s.niche || "Life science"} microscopy`;
  const usingSource = !!task && !!s.sourceLocal && !s.svg && !s.photoUri;
  const unusable = !!task && /^IMAGE UNUSABLE/i.test(task.whyItWorks);

  return (
    <>
      <Text style={T.section}>1) Choose the niche</Text>
      <Chips options={NICHES} value={s.niche} onPick={(v) => set({ niche: v || s.niche, subdomain: "", trapType: "" })} />
      <TextInput style={T.inputSingle} placeholder="Or type your own niche" placeholderTextColor={C.faint} value={s.niche} onChangeText={(v) => set({ niche: v, subdomain: "", trapType: "" })} />

      <Text style={T.section}>2) Choose the sub-domain (optional)</Text>
      <Chips options={subdomains(s.niche)} value={s.subdomain} onPick={(v) => set({ subdomain: v })} />
      <TextInput style={T.inputSingle} placeholder="Or type your own, e.g. NMR spectra, mitosis, titration" placeholderTextColor={C.faint} value={s.subdomain} onChangeText={(v) => set({ subdomain: v })} />

      <Text style={T.section}>3) Blind-spot type (optional)</Text>
      <Chips options={trapTypes(s.niche)} value={s.trapType} onPick={(v) => set({ trapType: v })} />

      <Text style={T.section}>4) Define the blind spot (optional)</Text>
      <TextInput
        style={T.input} multiline placeholderTextColor={C.faint} value={s.blindSpot} onChangeText={(v) => set({ blindSpot: v })}
        placeholder="The specific thing the model gets wrong, e.g. misses the rare cellular marker that separates treatment from control. Leave empty and the AI picks one."
      />

      <Text style={T.section}>5) Open-source reference image (optional)</Text>
      <Text style={T.muted}>Pick a real, open-licence image and the AI builds the task on that exact image. Skip this and the AI draws the image itself.</Text>
      <TextInput style={T.inputSingle} placeholder={defaultQuery} placeholderTextColor={C.faint} value={s.query} onChangeText={(v) => set({ query: v })} onSubmitEditing={search} returnKeyType="search" />
      <Button title="Search image" kind="ghost" small onPress={search} />
      {s.results.map((r) => {
        const on = s.source?.url === r.url;
        return (
          <Card key={r.url} selected={on}>
            <View style={styles.sourceRow}>
              <Image source={{ uri: r.thumb }} style={styles.thumb} resizeMode="cover" />
              <View style={styles.flex}>
                <Text style={T.bold} numberOfLines={2}>{r.title}</Text>
                <Text style={T.muted}>{r.source} · {r.license}</Text>
              </View>
            </View>
            <Button title={on ? "Using this source · tap to remove" : "Use this source"} kind={on ? "primary" : "ghost"} small onPress={() => set({ source: on ? null : r })} />
          </Card>
        );
      })}

      {projects.length > 0 && (
        <>
          <Text style={T.section}>Playbook guide (optional)</Text>
          <Chips options={projects.map((p) => p.name)} value={guide?.name ?? ""} onPick={(v) => set({ guideId: projects.find((p) => p.name === v)?.id ?? "" })} />
        </>
      )}

      <Text style={T.section}>Trap image</Text>
      {s.source ? (
        <Text style={T.muted}>Using the source image you picked.</Text>
      ) : imageAi ? (
        <>
          <Chips options={["Realistic (image AI)", "Diagram (Claude)"]} value={s.realistic ? "Realistic (image AI)" : "Diagram (Claude)"} onPick={(v) => set({ realistic: v ? v.startsWith("Realistic") : !s.realistic })} />
          <Text style={T.muted}>
            {s.realistic
              ? `Claude writes the task, ${providerInfo(imageAi.provider).label} renders a realistic scene, then Claude re-reads the finished picture and fits the answer and distractors to it.`
              : "Claude writes the task and draws a precise labelled diagram."}
          </Text>
        </>
      ) : (
        <Text style={T.muted}>Claude draws a labelled diagram. For realistic, harder images, add an image AI key (OpenAI or Google Gemini) in Settings.</Text>
      )}

      <Button title={task ? "Generate another task" : "Generate full task"} onPress={() => generate()} />

      {task && (
        <>
          <Card>
            <Text style={T.section}>Blind spot</Text>
            <Text selectable style={T.body}>{task.blindSpot}</Text>
            {task.failurePoints.length > 0 && (
              <>
                <Text style={T.section}>Other failure points the AI suggests</Text>
                <Chips options={task.failurePoints} value={s.blindSpot} onPick={(v) => set({ blindSpot: v })} />
                <Text style={T.muted}>Tap one, then "Generate another task" to target it.</Text>
              </>
            )}
          </Card>

          <Card>
            <Text style={T.section}>Blind-spot prompt</Text>
            <Text selectable style={T.bold}>{task.question}</Text>
            <Button title="Share prompt" kind="ghost" small onPress={() => share(task.question)} />
          </Card>

          <Card>
            <Text style={T.section}>Trap image</Text>
            {usingSource ? (
              <>
                <Image source={{ uri: s.sourceLocal }} style={styles.sourceBig} resizeMode="contain" />
                <Text style={T.muted}>{s.source?.title} · {s.source?.source} · {s.source?.license}</Text>
                <Text style={T.muted}>The task was written from this image. Download the full-size file from its source page before you submit.</Text>
                {!!s.source?.page && <Button title="Share source link" kind="ghost" small onPress={() => share(s.source!.page)} />}
              </>
            ) : s.svg || s.photoUri ? (
              <TrapImage ref={shown} key={s.svg || s.photoUri} svg={s.svg} photoUri={s.photoUri} />
            ) : (
              <Text style={T.muted}>No image yet.</Text>
            )}
            {!!s.svg && s.svgProblems.length > 0 && (
              <View style={styles.item}>
                <Text style={T.bold}>✗ The drawing does not fully match the answer yet</Text>
                {s.svgProblems.map((x, i) => <Text key={i} selectable style={T.muted}>• {x}</Text>)}
                <Text style={T.muted}>Redraw before you use it.</Text>
              </View>
            )}
            {!!s.svg && s.svgProblems.length === 0 && <Text style={T.muted}>✓ Checked: the drawing matches the task's stated values.</Text>}
            {unusable && <Text style={T.error}>The rendered image can't support a sound question ({task.whyItWorks.replace(/^IMAGE UNUSABLE:?\s*/i, "").split(".")[0]}). Render it again.</Text>}
            <View style={T.row}>
              {imageAi && <Button title={s.photoUri ? "Render again" : `Render with ${providerInfo(imageAi.provider).label}`} kind="ghost" small onPress={() => render(task)} />}
              <Button title={s.svg ? "Redraw diagram" : "Draw diagram"} kind="ghost" small onPress={() => draw(task)} />
            </View>
            <Button title="Free photo-style image" kind="ghost" small onPress={photo} />
            <Text style={T.muted}>
              {imageAi ? "Rendered images are realistic and harder to read; the task is refitted to each one. " : ""}
              The diagram keeps labels exact. The free generator can get details wrong and the task is not refitted to it, so run the playbook review before use.
            </Text>
          </Card>

          <Card>
            <Text style={T.section}>Trap test</Text>
            {!s.test ? (
              <Text style={T.muted}>Runs the question and image past a fresh model that has not seen the answer. A good trap makes it answer wrongly.</Text>
            ) : (
              <>
                <Text style={T.bold}>{s.test.held ? "✓ Trap held: the model got it wrong" : "✗ Too easy: the model got it right"}</Text>
                <Text selectable style={T.body}>Model answered: {s.test.answer}</Text>
                {!!s.test.reasoning && <Text selectable style={T.muted} numberOfLines={6}>{s.test.reasoning}</Text>}
                {!!s.test.verdict && <Text selectable style={T.muted}>{s.test.verdict}</Text>}
                <Text style={T.muted}>Tested with Claude. Other models have different weak spots, so also run it against the model you are targeting.</Text>
              </>
            )}
            <View style={T.row}>
              <Button title={s.test ? "Test again" : "Test the trap"} kind="ghost" small onPress={test} />
              {s.test && !s.test.held && (
                <Button title="Make it harder" small onPress={() => generate({ question: task.question, solvedBy: `${s.test!.answer}. ${s.test!.reasoning}`.slice(0, 900) })} />
              )}
            </View>
          </Card>

          <Card>
            <Text style={T.section}>Image generation prompt</Text>
            <Text selectable style={T.body}>{task.imagePrompt}</Text>
            <Button title="Share image prompt" kind="ghost" small onPress={() => share(task.imagePrompt)} />
          </Card>

          <Card>
            <Text style={T.section}>Expected solution</Text>
            <Text selectable style={T.bold}>{task.correctAnswer}</Text>
            {!!task.justification && <Text selectable style={T.body}>{task.justification}</Text>}
            {task.steps.map((st, i) => <Text key={i} selectable style={T.body}>{i + 1}. {st}</Text>)}
          </Card>

          <Card>
            <Text style={T.section}>Distractors</Text>
            {task.distractors.map((d, i) => (
              <View key={i} style={styles.item}>
                <Text selectable style={T.bold}>{i + 1}. {d.answer}</Text>
                {!!d.error && <Text selectable style={T.muted}>{d.error}</Text>}
              </View>
            ))}
          </Card>

          <Card>
            <Text style={T.section}>Why this trap works</Text>
            <Text selectable style={T.body}>{task.whyItWorks}</Text>
            {task.verify.length > 0 && <Text style={T.section}>Must be visible in the image</Text>}
            {task.verify.map((v, i) => <Text key={i} selectable style={T.body}>• {v}</Text>)}
          </Card>

          <Card>
            <Text style={T.section}>Playbook review</Text>
            {s.review.length === 0 && <Text style={T.muted}>A strict second pass over the task and its image: answer, steps, distractors, image, source and failure mode.</Text>}
            {s.review.map((r, i) => (
              <View key={i} style={styles.item}>
                <Text style={T.bold}>{r.pass ? "✓" : "✗"} {r.check}</Text>
                {!!r.note && <Text selectable style={T.muted}>{r.note}</Text>}
              </View>
            ))}
            <Button title={s.review.length ? "Review again" : "Review against playbook"} kind="ghost" small onPress={review} />
          </Card>

          <Button title="Save / share task" onPress={() => share(stompText(task, s.sourceLocal ? s.source : null))} />
          <Button title="Start over" kind="ghost" onPress={() => setS(fresh)} />
        </>
      )}
    </>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, gap: 2 },
  sourceRow: { flexDirection: "row", gap: 10, alignItems: "center" },
  thumb: { width: 64, height: 64, borderRadius: 8, backgroundColor: "#1a1a1a" },
  sourceBig: { width: "100%", aspectRatio: 1, borderRadius: 8, backgroundColor: "#111" },
  item: { borderTopWidth: 1, borderColor: C.line, paddingTop: 8, gap: 2 },
});
