// On-device text recognition. The native module only exists in a development or release
// build, so it is loaded lazily: in Expo Go the app still runs and simply skips this step.
export async function readText(uri: string): Promise<string> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const ocr = require("expo-mlkit-ocr") as typeof import("expo-mlkit-ocr");
    if (!ocr.isSupported()) return "";
    const result = await ocr.recognizeText(uri);
    return (result?.text || "").trim();
  } catch {
    return "";
  }
}
