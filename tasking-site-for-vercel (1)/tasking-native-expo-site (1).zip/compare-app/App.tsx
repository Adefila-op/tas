import { StatusBar } from "expo-status-bar";
import * as DocumentPicker from "expo-document-picker";
import * as ImagePicker from "expo-image-picker";
import * as SecureStore from "expo-secure-store";
import { useCallback, useEffect, useState } from "react";
import { ActivityIndicator, Alert, AppState, BackHandler, Image, Pressable, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import Capture from "./Capture";
import type { GuidelineSource } from "./projects";
import { Access, activateAccess, checkGate, clearAccess, daysLeft, getOrCreateDeviceId } from "./access";
import { AudioNotes, cancelRequest, compareItems, MediaItem, QuestionFormat, TaskType, testKey, Verdict } from "./compare";
import { ImageAi, loadImageAi, PROVIDERS, providerInfo, saveImageAi } from "./imagegen";
import LumiereStudio, { Job } from "./LumiereStudio";
import PageAssistant from "./PageAssistant";
import { addHistory, clearHistory, HistoryEntry, listHistory, verdictText } from "./history";
import {
  addProjectFromFile, addProjectFromPhotos, addProjectFromText, deleteProject, listProjects, loadGuidelines, Project,
} from "./projects";
import { BottomNav, Button, C, Card, Chips, Empty, Header, MenuRow, NavKey, Progress, Screen, Steps, T, Toast } from "./ui";

const KEY_NAME = "anthropic_api_key";
const LAST_GUIDE_KEY = "last_guide_id";

type Step =
  | "welcome" | "tasking" | "stomp" | "author" | "pageAssistant" | "onboarding"
  | "projects" | "pickProject" | "capture" | "result" | "history" | "settings";

type TaskChoice = {
  n: string;
  label: string;
  sub: string;
  type: TaskType;
  format: QuestionFormat;
  upload?: boolean;  // option 4: upload a new guide first
  stomp?: boolean;   // option 3: review or write a Lumiere task
  page?: boolean;    // option 5: answer the question on a photographed page
  noGuide?: boolean; // options 1-2: run on the standard criteria, without an uploaded guide
};

const TASK_MENU: TaskChoice[] = [
  { n: "1", label: "Compare images", sub: "Two images, which is better", type: "image", format: "video_annotation", noGuide: true },
  { n: "2", label: "Compare videos", sub: "Two videos, which is better", type: "video", format: "video_annotation", noGuide: true },
  { n: "3", label: "Stomp a model", sub: "Build a trap task in Lumiere Studio, or review a pair", type: "image", format: "lumiere", stomp: true },
  { n: "4", label: "Another project", sub: "Upload the project's guidelines first", type: "image", format: "video_annotation", upload: true },
  { n: "5", label: "Page assistant", sub: "Answer the question on a webpage screenshot", type: "image", format: "video_annotation", page: true },
];

const kindLabel = (p: Project) => (p.kind === "pdf" ? "PDF" : p.kind === "images" ? `${p.paths?.length ?? 1} photo page${(p.paths?.length ?? 1) === 1 ? "" : "s"}` : "Text");
const winnerLabel = (v: Verdict) => (v.winner === "tie" ? "Tie" : `Item ${v.winner} is better`);

export default function App() {
  return <SafeAreaProvider><Main /></SafeAreaProvider>;
}

function Main() {
  const [step, setStep] = useState<Step>("welcome");
  const [projects, setProjects] = useState<Project[]>([]);
  const [project, setProject] = useState<Project | null>(null);
  const [choice, setChoice] = useState<TaskChoice>(TASK_MENU[0]);
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState("");
  const [verdict, setVerdict] = useState<Verdict | null>(null);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [pages, setPages] = useState<string[]>([]);
  const [guideName, setGuideName] = useState("");
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteName, setPasteName] = useState("");
  const [pasteText, setPasteText] = useState("");
  const [access, setAccess] = useState<Access | null>(null);
  const [accessCode, setAccessCode] = useState("");
  const [gate, setGate] = useState<"checking" | "open" | "locked">("checking");
  const [gateNote, setGateNote] = useState("");
  const [deviceId, setDeviceId] = useState("");
  const [activating, setActivating] = useState(false);
  const [imageAi, setImageAi] = useState<ImageAi | null>(null);      // saved, in use
  const [imageDraft, setImageDraft] = useState<ImageAi>({ provider: "openai", key: "", model: "" }); // being edited in Settings
  const [lastPair, setLastPair] = useState<{ a: MediaItem; b: MediaItem; notes: AudioNotes } | null>(null);
  const [viewing, setViewing] = useState<HistoryEntry | null>(null); // history entry open on the result screen
  const [savedGuide, setSavedGuide] = useState<Project | null>(null); // guide just saved in onboarding
  const [swapped, setSwapped] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [pingNote, setPingNote] = useState("");
  const [lastGuideId, setLastGuideId] = useState<string | null>(null);
  const [cameFrom, setCameFrom] = useState<Step>("welcome");

  const say = (msg: string) => { setToast(""); setTimeout(() => setToast(msg), 10); };
  const refresh = useCallback(async () => setProjects(await listProjects()), []);

  useEffect(() => {
    (async () => {
      setApiKey((await SecureStore.getItemAsync(KEY_NAME)) || "");
      setLastGuideId(await SecureStore.getItemAsync(LAST_GUIDE_KEY));
      const img = await loadImageAi();
      setImageAi(img); if (img) setImageDraft(img);
      setDeviceId(await getOrCreateDeviceId());
      await refreshGate();
      await refresh();
      setHistory(await listHistory());
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refresh]);

  const go = (s: Step) => { setError(""); if (s !== "onboarding") setSavedGuide(null); setStep(s); };
  const goNav = (k: NavKey) => { setCameFrom("welcome"); go(k === "home" ? "welcome" : k === "guides" ? "projects" : k); };
  const navKey: NavKey = step === "projects" ? "guides" : step === "history" ? "history" : step === "settings" ? "settings" : "home";

  // ---------- settings ----------
  const saveSettings = async () => {
    try {
      await SecureStore.setItemAsync(KEY_NAME, apiKey.trim());
      say("Key saved");
    } catch (e: any) {
      Alert.alert("Not saved", e?.message || "Could not save the key on this phone.");
    }
  };

  const testConnection = async () => {
    if (!apiKey.trim()) return setPingNote("Paste your Anthropic API key first.");
    setPingNote("Checking…");
    try {
      setPingNote(await testKey(apiKey.trim()));
    } catch (e: any) {
      setPingNote(e?.message || "Could not check the key.");
    }
  };

  const saveImageSettings = async () => {
    try {
      const next = imageDraft.key.trim() ? { ...imageDraft, key: imageDraft.key.trim(), model: imageDraft.model.trim() } : null;
      await saveImageAi(next);
      setImageAi(next);
      say(next ? "Image AI saved" : "Image AI removed");
    } catch (e: any) {
      Alert.alert("Not saved", e?.message || "Could not save the image AI settings on this phone.");
    }
  };

  // Asks the server whether this phone may use the app.
  const refreshGate = useCallback(async () => {
    const g = await checkGate();
    if (g.open) { setAccess(g.access); setGate("open"); setGateNote(""); }
    else { setAccess(null); setGate("locked"); setGateNote(g.message); }
  }, []);

  // Re-check whenever the app comes back to the front, so a revoked or expired code locks promptly.
  useEffect(() => {
    const sub = AppState.addEventListener("change", (state) => { if (state === "active") refreshGate(); });
    return () => sub.remove();
  }, [refreshGate]);

  const activateCode = async () => {
    setGateNote(""); setActivating(true);
    try {
      const saved = await activateAccess(accessCode);
      setAccess(saved); setAccessCode(""); setGate("open");
      say("Access code accepted");
    } catch (e: any) {
      setGateNote(e?.message || "The code could not be confirmed.");
    } finally {
      setActivating(false);
    }
  };

  const removeCode = () => {
    Alert.alert("Remove access code", "This phone will be locked until a code is entered again.", [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: async () => { await clearAccess(); setAccess(null); setGate("locked"); setGateNote(""); go("welcome"); } },
    ]);
  };

  // Runs a long action for the Lumiere and Page assistant screens behind the shared progress card.
  const job: Job = async (stageText, fn, opts) => {
    if (opts?.needsKey !== false && !apiKey.trim()) { setError("Add your Anthropic API key in Settings."); return undefined; }
    setError(""); setBusy(true); setStage(stageText);
    try {
      return await fn(setStage);
    } catch (e: any) {
      setError(e?.message || "That did not work. Try again.");
      return undefined;
    } finally {
      setBusy(false); setStage("");
    }
  };

  // ---------- guides ----------
  const chooseProject = async (p: Project) => {
    setProject(p);
    setLastGuideId(p.id);
    await SecureStore.setItemAsync(LAST_GUIDE_KEY, p.id).catch(() => {});
  };

  const uploadFile = async () => {
    try {
      const res = await DocumentPicker.getDocumentAsync({
        type: ["application/pdf", "text/plain", "text/markdown", "text/html", "application/json"],
        copyToCacheDirectory: true,
      });
      if (res.canceled || !res.assets?.[0]) return;
      const file = res.assets[0];
      const saved = await addProjectFromFile(file.name.replace(/\.[^.]+$/, ""), file.uri, file.name, file.mimeType);
      await refresh();
      await chooseProject(saved);
      say(`Saved "${saved.name}"`);
    } catch (e: any) {
      Alert.alert("Upload failed", e?.message || "Could not read that file.");
    }
  };

  const savePasted = async () => {
    if (!pasteName.trim() || !pasteText.trim()) return Alert.alert("Missing", "Add a name and the guidelines text.");
    try {
      const saved = await addProjectFromText(pasteName.trim(), pasteText);
      setPasteName(""); setPasteText(""); setPasteMode(false);
      await refresh();
      await chooseProject(saved);
      say(`Saved "${saved.name}"`);
    } catch (e: any) {
      Alert.alert("Save failed", e?.message || "Could not save this guide.");
    }
  };

  const removeProject = (p: Project) => {
    Alert.alert("Delete guide", `Delete "${p.name}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        await deleteProject(p.id);
        if (project?.id === p.id) setProject(null);
        await refresh();
        say("Guide deleted");
      } },
    ]);
  };

  const snapPage = async () => {
    const cam = await ImagePicker.requestCameraPermissionsAsync();
    if (!cam.granted) return Alert.alert("Permission needed", "Allow camera access to snap guideline pages.");
    const res = await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], quality: 0.5 });
    if (!res.canceled && res.assets?.[0]) { setSavedGuide(null); setPages((p) => [...p, res.assets![0].uri]); }
  };

  const pickPages = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) return Alert.alert("Permission needed", "Allow photo access to pick guideline pages.");
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.5, allowsMultipleSelection: true });
    if (!res.canceled && res.assets?.length) { setSavedGuide(null); setPages((p) => [...p, ...res.assets.map((a) => a.uri)]); }
  };

  const saveSnapped = async () => {
    if (pages.length === 0) return Alert.alert("No pages", "Snap at least one page of the guideline.");
    const name = guideName.trim() || `Guide ${new Date().toLocaleDateString()}`;
    try {
      const saved = await addProjectFromPhotos(name, pages);
      setPages([]); setGuideName(""); setSavedGuide(saved);
      await refresh();
      await chooseProject(saved);
      say(`Saved "${saved.name}"`);
    } catch (e: any) {
      Alert.alert("Save failed", e?.message || "Could not save these pages.");
    }
  };

  // ---------- tasks ----------
  const pickTask = (c: TaskChoice) => {
    setChoice(c);
    setError("");
    if (c.noGuide) { setProject(null); return setStep("capture"); }
    if (c.stomp) return setStep("stomp");
    if (c.page) return setStep("pageAssistant");
    if (c.upload) { setCameFrom("tasking"); return setStep("projects"); }
    setStep("pickProject");
  };

  const runCompare = async (a: MediaItem, b: MediaItem, notes: AudioNotes = { a: "", b: "" }, isSwapped = false) => {
    setError(""); setVerdict(null); setViewing(null); setLastPair({ a, b, notes }); setSwapped(isSwapped);
    if (!project && !choice.noGuide) return setError("Choose a guide first.");
    if (!apiKey.trim()) return setError("Add your Anthropic API key in Settings.");
    setBusy(true); setStage("Loading the guide…");
    try {
      const guidelines: GuidelineSource = project
        ? await loadGuidelines(project)
        : { kind: "text", text: "No project guide was uploaded. Judge each dimension by its standard meaning: how well the item follows the task, its visual quality and artefacts, its realism, and for videos its audio as described in the notes." };
      const result = await compareItems(apiKey.trim(), guidelines, {
        type: choice.type, format: choice.format, question, a, b, audioNotes: notes, onProgress: setStage,
      });
      setVerdict(result);
      setStep("result");
      addHistory({ task: `${choice.n}) ${choice.label}`, type: choice.type, format: choice.format, guide: project?.name ?? null, question, verdict: result })
        .then(async () => setHistory(await listHistory())).catch(() => {});
    } catch (e: any) {
      setError(e?.message || "Comparison failed.");
    } finally {
      setBusy(false); setStage("");
    }
  };

  const rerunSwapped = async () => {
    if (!lastPair) return;
    await runCompare(lastPair.b, lastPair.a, { a: lastPair.notes.b, b: lastPair.notes.a }, !swapped);
  };

  const shareVerdict = async () => {
    if (!verdict) return;
    // a result opened from History is shared with its own task, guide and question, not the current ones
    const text = verdictText(viewing ?? { id: "", at: Date.now(), task: `${choice.n}) ${choice.label}`, type: choice.type, format: choice.format, guide: project?.name ?? null, question, verdict });
    await Share.share({ message: text }).catch(() => {});
  };

  // Android hardware back follows the same route as each screen's Back link.
  useEffect(() => {
    const sub = BackHandler.addEventListener("hardwareBackPress", () => {
      if (busy) return true; // a request is running; Cancel is on the progress card
      const fromTask = choice.upload && cameFrom === "tasking";
      const target: Partial<Record<Step, Step>> = {
        tasking: "welcome", stomp: "tasking", author: "stomp", pageAssistant: "tasking", onboarding: "welcome",
        projects: fromTask ? "tasking" : "welcome",
        pickProject: choice.stomp ? "stomp" : choice.upload ? "projects" : "tasking",
        capture: project ? "pickProject" : "tasking",
        history: "welcome", settings: "welcome",
        result: lastPair ? "capture" : "history",
      };
      const to = target[step];
      if (!to) return false; // home screen: let the system close the app
      go(to);
      return true;
    });
    return () => sub.remove();
  }, [step, busy, choice, cameFrom, project, lastPair]);

  const nav = <BottomNav active={navKey} onGo={goNav} />;
  const overlay = <><Progress stage={stage} onCancel={busy ? cancelRequest : undefined} /><Toast message={toast} /></>;

  // ================= ACCESS GATE =================
  if (gate === "checking") {
    return (
      <Screen scroll={false}>
        <StatusBar style="light" />
        <View style={styles.gate}><ActivityIndicator color="#fff" size="large" /><Text style={T.muted}>Checking access…</Text></View>
      </Screen>
    );
  }
  if (gate === "locked") {
    return (
      <Screen>
        <StatusBar style="light" />
        <View style={styles.hero}>
          <Text style={styles.brand}>Tasking</Text>
          <Text style={T.muted}>Enter your access code to unlock the app.</Text>
        </View>
        <TextInput style={T.inputSingle} value={accessCode} onChangeText={setAccessCode} autoCapitalize="characters" autoCorrect={false} placeholder="TASK-2026-XXXXXXXX" placeholderTextColor={C.faint} onSubmitEditing={activateCode} returnKeyType="go" />
        <Button title="Activate" onPress={activateCode} loading={activating} disabled={!accessCode.trim()} />
        {!!gateNote && <Text style={T.error}>{gateNote}</Text>}
        <Text style={T.muted}>A code works on the phone it is first used on. If you change phone, ask for the code to be reset.</Text>
        {!!deviceId && <Text selectable style={T.muted}>This phone: {deviceId}</Text>}
      </Screen>
    );
  }

  // ================= WELCOME =================
  if (step === "welcome") {
    const last = history[0];
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <View style={styles.hero}>
          <Text style={styles.brand}>Tasking</Text>
          <Text style={T.muted}>
            {apiKey.trim() ? "Ready" : "Add your API key in Settings"} · {projects.length} guide{projects.length === 1 ? "" : "s"}
          </Text>
        </View>
        <Pressable style={({ pressed }) => [styles.big, pressed && styles.pressed]} onPress={() => go("tasking")}>
          <Text style={styles.bigTitle}>Tasking</Text>
          <Text style={styles.bigSub}>Compare images or videos, or stomp a model</Text>
        </Pressable>
        <Pressable style={({ pressed }) => [styles.big, styles.bigGhost, pressed && styles.pressed]} onPress={() => go("onboarding")}>
          <Text style={[styles.bigTitle, { color: C.text }]}>Onboarding</Text>
          <Text style={[styles.bigSub, { color: C.muted }]}>Snap a new project's guidelines</Text>
        </Pressable>

        {projects.length === 0 && (
          <Empty title="Add a guide when you have one" hint="Option 4 and pair reviews need a guide. Snap its pages in Onboarding, or upload a file under Guides." action="Snap a guide" onAction={() => go("onboarding")} />
        )}
        <Pressable style={({ pressed }) => [styles.big, styles.bigGhost, pressed && styles.pressed]} onPress={() => go("pageAssistant")}>
          <Text style={[styles.bigTitle, { color: C.text }]}>Page assistant</Text>
          <Text style={[styles.bigSub, { color: C.muted }]}>Answer the question on a webpage screenshot</Text>
        </Pressable>
        {access && daysLeft(access) <= 5 && (
          <Card onPress={() => goNav("settings")}>
            <Text style={T.section}>Access ends soon</Text>
            <Text style={T.muted}>Your code expires in {daysLeft(access)} day{daysLeft(access) === 1 ? "" : "s"}. Ask for a renewal to keep using the app.</Text>
          </Card>
        )}
        {last && (
          <Card onPress={() => go("history")}>
            <Text style={T.section}>Last result</Text>
            <Text style={T.bold}>{winnerLabel(last.verdict)} · {Math.round(last.verdict.confidence * 100)}%</Text>
            <Text style={T.muted} numberOfLines={2}>{last.verdict.reason}</Text>
          </Card>
        )}
      </Screen>
    );
  }

  // ================= TASKING MENU =================
  if (step === "tasking") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Tasking" sub="What kind of task is this?" onBack={() => go("welcome")} />
        {TASK_MENU.map((c) => (
          <MenuRow
            key={c.n} n={c.n} title={c.label} hint={c.sub} onPress={() => pickTask(c)}
            badge={c.noGuide ? "no guide needed" : c.stomp ? "Lumiere" : c.page ? "reads the page" : undefined}
          />
        ))}
      </Screen>
    );
  }

  // ================= STOMP A MODEL =================
  if (step === "stomp") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Stomp a model" sub="Uses the Lumiere playbook" onBack={() => go("tasking")} />
        <MenuRow title="Review two items" hint="Check a pair against the Lumiere checks and get a verdict" onPress={() => { setChoice(TASK_MENU[2]); go("pickProject"); }} />
        <MenuRow title="Lumiere Studio" hint="The AI builds a full blind-spot task: question, image, solution, distractors" onPress={() => go("author")} />
      </Screen>
    );
  }

  if (step === "author") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Lumiere Studio" sub="Step-by-step blind-spot task builder. The AI writes the task, supplies the image and tests it." onBack={() => go("stomp")} />
        {!!error && <Text style={T.error}>{error}</Text>}
        <LumiereStudio apiKey={apiKey.trim()} imageAi={imageAi} projects={projects} job={job} say={say} />
        {!!error && <Text style={T.error}>{error}</Text>}
      </Screen>
    );
  }

  // ================= PAGE ASSISTANT =================
  if (step === "pageAssistant") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Page assistant" sub="Answer the question on a webpage screenshot" onBack={() => go("tasking")} />
        <PageAssistant apiKey={apiKey.trim()} projects={projects} job={job} />
        {!!error && <Text style={T.error}>{error}</Text>}
      </Screen>
    );
  }

  // ================= ONBOARDING =================
  if (step === "onboarding") {
    const justSaved = !!savedGuide && pages.length === 0;
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Onboarding" sub="Snap every page of the guideline, then save it as a guide." onBack={() => go("welcome")} />
        <Steps total={3} current={justSaved ? 2 : pages.length > 0 ? 1 : 0} labels={["Snap pages", "Save guide", "Compare"]} />
        <TextInput style={T.inputSingle} placeholder="Guide name (optional)" placeholderTextColor={C.faint} value={guideName} onChangeText={setGuideName} />
        <View style={T.row}>
          <Button title={`Snap page${pages.length ? ` (${pages.length})` : ""}`} onPress={snapPage} small />
          <Button title="From photos" kind="ghost" onPress={pickPages} small />
        </View>
        {pages.length > 0 && (
          <View style={styles.pages}>
            {pages.map((uri, i) => (
              <Pressable key={uri + i} onLongPress={() => setPages((p) => p.filter((_, j) => j !== i))} style={styles.page} accessibilityRole="button" accessibilityLabel={`Page ${i + 1}`} accessibilityHint="Long press to remove this page">
                <Image source={{ uri }} style={styles.pageImg} resizeMode="cover" />
                <Text style={styles.pageNum}>{i + 1}</Text>
              </Pressable>
            ))}
          </View>
        )}
        {pages.length > 0 && <Text style={T.muted}>Long-press a page to remove it. Pages are used in this order as the reference, and the first page is the primary one.</Text>}
        <Button title="Save guide" onPress={saveSnapped} disabled={pages.length === 0} />
        {justSaved && (
          <Card>
            <Text style={T.section}>Saved</Text>
            <Text style={T.bold}>{savedGuide!.name} · {kindLabel(savedGuide!)}</Text>
            <View style={T.row}>
              <Button title="Compare images" small onPress={() => { setChoice(TASK_MENU[0]); go("capture"); }} />
              <Button title="Compare videos" small kind="ghost" onPress={() => { setChoice(TASK_MENU[1]); go("capture"); }} />
            </View>
          </Card>
        )}
      </Screen>
    );
  }

  // ================= GUIDES =================
  if (step === "projects") {
    const fromTask = choice.upload && cameFrom === "tasking";
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Guides" sub={fromTask ? "Add this project's guidelines, then pick one." : "Guidelines saved on this phone."} onBack={() => go(fromTask ? "tasking" : "welcome")} />
        <View style={T.row}>
          <Button title="Upload file" onPress={uploadFile} small />
          <Button title={pasteMode ? "Cancel" : "Paste text"} kind="ghost" onPress={() => setPasteMode(!pasteMode)} small />
          <Button title="Snap" kind="ghost" onPress={() => go("onboarding")} small />
        </View>
        {pasteMode && (
          <Card>
            <TextInput style={T.inputSingle} placeholder="Guide name" placeholderTextColor={C.faint} value={pasteName} onChangeText={setPasteName} />
            <TextInput style={T.input} multiline placeholder="Paste the guidelines" placeholderTextColor={C.faint} value={pasteText} onChangeText={setPasteText} />
            <Button title="Save guide" onPress={savePasted} />
          </Card>
        )}
        {projects.length === 0 && !pasteMode && (
          <Empty title="No guides yet" hint="Upload a PDF or text file, paste text, or snap the pages with the camera." />
        )}
        {projects.map((p) => (
          <Card key={p.id} selected={p.id === project?.id}>
            <View style={styles.guideRow}>
              <View style={{ flex: 1 }}>
                <Text style={T.bold}>{p.name}</Text>
                <Text style={T.muted}>
                  {kindLabel(p)}{p.id === lastGuideId ? " · last used" : ""}
                </Text>
              </View>
              <Pressable onPress={() => removeProject(p)} hitSlop={8} accessibilityRole="button" accessibilityLabel={`Delete ${p.name}`}><Text style={styles.linkDanger}>Delete</Text></Pressable>
            </View>
          </Card>
        ))}
        {projects.length > 0 && fromTask && (
          <Button title="Continue: pick a guide" onPress={() => go("pickProject")} />
        )}
      </Screen>
    );
  }

  // ================= PICK GUIDE =================
  if (step === "pickProject") {
    const back: Step = choice.stomp ? "stomp" : choice.upload ? "projects" : "tasking";
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title={choice.label} sub="Which guide applies?" onBack={() => go(back)} />
        <Steps total={3} current={0} labels={["Guide", "Capture", "Result"]} />
        {projects.length === 0 && (
          <Empty title="No guides yet" hint="Add one first." action="Add a guide" onAction={() => { setCameFrom("tasking"); go("projects"); }} />
        )}
        {projects.map((p) => {
          return (
            <MenuRow
              key={p.id} title={p.name}
              hint={kindLabel(p)}
              badge={p.id === lastGuideId ? "last used" : undefined}
              onPress={async () => { await chooseProject(p); go("capture"); }}
            />
          );
        })}
      </Screen>
    );
  }

  // ================= CAPTURE =================
  if (step === "capture") {
    const noGuide = !project;
    const back: Step = noGuide ? "tasking" : "pickProject";
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title={choice.label} sub={project ? `Guide: ${project.name}` : "Using the standard criteria"} onBack={() => go(back)} />
        <Steps total={3} current={1} labels={noGuide ? ["Task", "Capture", "Result"] : ["Guide", "Capture", "Result"]} />
        <Capture
          type={choice.type}
          questionLabel={choice.type === "generation" ? "Generation prompt" : "Question (optional)"}
          question={question}
          setQuestion={setQuestion}
          busy={busy}
          onCompare={(a, b, notes) => runCompare(a, b, notes)}
        />
        {!!error && <Text style={T.error}>{error}</Text>}
      </Screen>
    );
  }

  // ================= HISTORY =================
  if (step === "history") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="History" sub={history.length ? `${history.length} saved result${history.length === 1 ? "" : "s"}` : undefined} onBack={() => go("welcome")} />
        {history.length === 0 && <Empty title="No results yet" hint="Verdicts are saved here after each comparison." action="Start tasking" onAction={() => go("tasking")} />}
        {history.map((h) => (
          <Card key={h.id} onPress={() => { setVerdict(h.verdict); setViewing(h); setLastPair(null); setSwapped(false); go("result"); }}>
            <Text style={T.muted}>{new Date(h.at).toLocaleString()} · {h.task}{h.guide ? ` · ${h.guide}` : ""}</Text>
            <Text style={T.bold}>{winnerLabel(h.verdict)} · {Math.round(h.verdict.confidence * 100)}%</Text>
            <Text style={T.body} numberOfLines={2}>{h.verdict.reason}</Text>
          </Card>
        ))}
        {history.length > 0 && (
          <Button title="Clear history" kind="danger" onPress={() => Alert.alert("Clear history", "Delete all saved results?", [
            { text: "Cancel", style: "cancel" },
            { text: "Clear", style: "destructive", onPress: async () => { await clearHistory(); setHistory([]); say("History cleared"); } },
          ])} />
        )}
      </Screen>
    );
  }

  // ================= SETTINGS =================
  if (step === "settings") {
    return (
      <Screen nav={nav} overlay={overlay}>
        <StatusBar style="light" />
        <Header title="Settings" onBack={() => go("welcome")} />
        <Text style={T.section}>Anthropic API key</Text>
        <TextInput style={T.inputSingle} value={apiKey} onChangeText={setApiKey} autoCapitalize="none" autoCorrect={false} secureTextEntry placeholder="sk-ant-…" placeholderTextColor={C.faint} />
        <View style={T.row}>
          <Button title="Save key" onPress={saveSettings} small />
          <Button title="Test key" kind="ghost" onPress={testConnection} small />
        </View>
        {!!pingNote && <Text style={T.body}>{pingNote}</Text>}
        <Text style={T.section}>Image AI (optional)</Text>
        <Text style={T.muted}>Claude writes every task. Add a key here to have a second AI render realistic trap images, which are harder for a model to read than diagrams.</Text>
        <Chips options={PROVIDERS.map((p) => p.label)} value={providerInfo(imageDraft.provider).label} onPick={(v) => { const p = PROVIDERS.find((x) => x.label === v); if (p) setImageDraft({ ...imageDraft, provider: p.id, model: "" }); }} />
        <TextInput style={T.inputSingle} value={imageDraft.key} onChangeText={(v) => setImageDraft({ ...imageDraft, key: v })} autoCapitalize="none" autoCorrect={false} secureTextEntry placeholder={`${providerInfo(imageDraft.provider).label} API key (${providerInfo(imageDraft.provider).keyHint})`} placeholderTextColor={C.faint} />
        <TextInput style={T.inputSingle} value={imageDraft.model} onChangeText={(v) => setImageDraft({ ...imageDraft, model: v })} autoCapitalize="none" autoCorrect={false} placeholder={`Model (default ${providerInfo(imageDraft.provider).defaultModel})`} placeholderTextColor={C.faint} />
        <Button title={imageDraft.key.trim() ? "Save image AI" : imageAi ? "Remove image AI" : "Save image AI"} onPress={saveImageSettings} small />
        {imageAi && <Text style={T.body}>In use: {providerInfo(imageAi.provider).label} · {imageAi.model || providerInfo(imageAi.provider).defaultModel}</Text>}
        <Text style={T.section}>Access code</Text>
        {access && (
          <>
            <Text style={T.body}>{access.code}</Text>
            <Text style={T.muted}>Active on this phone until {new Date(access.expiresAt).toLocaleDateString()} · {daysLeft(access)} day{daysLeft(access) === 1 ? "" : "s"} left</Text>
            {!!deviceId && <Text selectable style={T.muted}>This phone: {deviceId}</Text>}
            <Button title="Remove code from this phone" kind="danger" onPress={removeCode} small />
          </>
        )}
        <Text style={T.muted}>The key is kept in this phone's secure storage. Guides and results stay on this phone. Each comparison or task sends the items and the guide to Anthropic. With an image AI set, the image prompt also goes to that provider.</Text>
      </Screen>
    );
  }

  // ================= RESULT =================
  const fromHistory = !lastPair;
  return (
    <Screen nav={nav} overlay={overlay}>
      <StatusBar style="light" />
      <Header title="Result" onBack={() => go(fromHistory ? "history" : "capture")} />
      {!fromHistory && <Steps total={3} current={2} labels={["Guide", "Capture", "Result"]} />}
      {lastPair && (
        <View style={T.row}>
          {(["A", "B"] as const).map((k) => {
            const item = lastPair[k === "A" ? "a" : "b"];
            const won = verdict?.winner === k;
            return (
              <View key={k} style={[styles.preview, won && styles.previewWin]}>
                {item.kind === "image"
                  ? <Image source={{ uri: item.uri }} style={styles.previewImg} resizeMode="cover" />
                  : <View style={[styles.previewImg, styles.centerBox]}><Text style={T.muted}>Video · {Math.round((item.durationMs ?? 0) / 1000)}s</Text></View>}
                <Text style={[T.muted, won && { color: C.text, fontWeight: "700" }]}>Item {k}{won ? " · winner" : ""}</Text>
              </View>
            );
          })}
        </View>
      )}
      {swapped && <Text style={T.muted}>This run had A and B switched. The original A is shown as B.</Text>}
      {verdict && (
        <>
          <Card>
            <Text style={styles.verdict}>{winnerLabel(verdict)}</Text>
            <View style={styles.bar}><View style={[styles.barFill, { width: `${Math.round(verdict.confidence * 100)}%` }]} /></View>
            <Text style={T.muted}>Confidence {Math.round(verdict.confidence * 100)}%{verdict.confidence < 0.6 ? " · low, treat as a coin flip" : ""}</Text>
            <Text style={T.body}>{verdict.reason}</Text>
          </Card>
          {verdict.criteria.length > 0 && (
            <Card>
              <Text style={T.section}>By criterion</Text>
              {verdict.criteria.map((c, i) => (
                <View key={i} style={styles.crit}>
                  <View style={styles.critHead}>
                    <Text style={[T.bold, { flex: 1 }]}>{c.guideline}</Text>
                    <Text style={styles.pill}>{c.better === "tie" ? "tie" : `${c.better} better`}</Text>
                  </View>
                  <View style={T.row}>
                    <View style={[styles.cell, c.better === "A" && styles.cellWin]}><Text style={T.muted}>A</Text><Text style={T.body}>{c.A || "—"}</Text></View>
                    <View style={[styles.cell, c.better === "B" && styles.cellWin]}><Text style={T.muted}>B</Text><Text style={T.body}>{c.B || "—"}</Text></View>
                  </View>
                </View>
              ))}
            </Card>
          )}
        </>
      )}
      {!!error && <Text style={T.error}>{error}</Text>}
      <View style={T.row}>
        <Button title="Share" onPress={shareVerdict} small disabled={busy} />
        {lastPair && <Button title="Swap and re-run" kind="ghost" onPress={rerunSwapped} small disabled={busy} />}
      </View>
      {lastPair && <Text style={T.muted}>Swap and re-run sends the same pair with A and B switched. A fair judge should flip its answer.</Text>}
      <Button title={fromHistory ? "Start a new comparison" : "Compare another pair"} onPress={() => go(fromHistory ? "tasking" : "capture")} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { gap: 4, marginBottom: 4 },
  brand: { fontSize: 34, fontWeight: "800", color: C.text, letterSpacing: -0.5 },
  big: { backgroundColor: C.text, padding: 22, borderRadius: 16, gap: 4 },
  bigGhost: { backgroundColor: "transparent", borderWidth: 1, borderColor: C.text },
  bigTitle: { color: "#000", fontSize: 20, fontWeight: "800" },
  bigSub: { color: "#444", fontSize: 13 },
  pressed: { opacity: 0.7 },
  gate: { flex: 1, alignItems: "center", justifyContent: "center", gap: 12 },
  pages: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  page: { width: 72, height: 96, borderRadius: 8, overflow: "hidden", borderWidth: 1, borderColor: C.line },
  pageImg: { width: "100%", height: "100%" },
  pageNum: { position: "absolute", bottom: 4, right: 6, color: C.text, fontWeight: "700", textShadowColor: "#000", textShadowRadius: 4 },
  guideRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  linkDanger: { color: C.muted, textDecorationLine: "underline" },
  preview: { flex: 1, gap: 4, borderRadius: 10, padding: 4, borderWidth: 2, borderColor: "transparent" },
  previewWin: { borderColor: C.text },
  previewImg: { width: "100%", height: 120, borderRadius: 8, backgroundColor: "#1a1a1a" },
  centerBox: { alignItems: "center", justifyContent: "center" },
  verdict: { fontSize: 22, fontWeight: "800", color: C.text },
  bar: { height: 6, backgroundColor: "#222", borderRadius: 3, overflow: "hidden" },
  barFill: { height: 6, backgroundColor: C.text },
  crit: { borderTopWidth: 1, borderColor: C.line, paddingTop: 10, gap: 8 },
  critHead: { flexDirection: "row", alignItems: "center", gap: 8 },
  pill: { color: C.text, fontSize: 12, borderWidth: 1, borderColor: C.text, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  cell: { flex: 1, gap: 2, padding: 8, borderRadius: 8, borderWidth: 1, borderColor: C.line },
  cellWin: { borderColor: C.text },
});
