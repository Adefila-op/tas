# Access codes, admin panel and customer site

- `server/setup.sql` creates the code database and its rules in Supabase.
- `site/` is the website for Vercel:
  - `site/index.html` is the customer page: sign in with an access code, see the account, download the app.
  - `site/admin/index.html` is the admin panel, served at `/admin`.

## 1. Database (once)

Open your Supabase project → **SQL Editor** → **New query**. Paste all of `setup.sql` and press **Run**.
If you ran an earlier version, run this one again; it keeps your existing codes.

## 2. Admin login (once)

Supabase → **Authentication → Users → Add user → Create new user**. Enter your email and a strong
password, and tick **Auto Confirm User**. The first account to sign in on the admin page becomes the
admin; nobody else can.

## 3. Put the site on Vercel

With GitHub:

1. Push this project to a GitHub repository.
2. On vercel.com choose **Add New → Project** and import the repository.
3. Set **Root Directory** to `site` and **Framework Preset** to `Other`. Leave the build command empty.
4. Deploy. The customer page is at your Vercel address, the admin panel at `/admin`.

Or from a terminal, inside the `site` folder: `npx vercel --prod`.

## 4. Host the APK and set the download link

The APK is too large to keep on Vercel, so host the file elsewhere and paste its link into the admin
panel under **App download**:

- **GitHub Releases** (recommended): in a repository, create a release and attach the `.apk`.
  Copy the file's link. The repository must be public for customers to download it.
- **The EAS build link**: works immediately, but Expo removes old build files after a while,
  so check it still works.

Customers only see the download button after signing in with a code that is not switched off or
expired. The link itself is a normal link: anyone who has it can download the file. That is fine,
because the app stays locked without a valid code.

## How it behaves

- A code's days start counting the first time it is activated in the app.
- A code works on as many phones as you allowed (default 1). "Reset phones" frees it for a new phone.
- The app checks the code every time it opens. Switched-off and expired codes lock the app.
- With no internet, the app keeps working for 3 days, never past the code's end date.
- Eight wrong codes from one phone in ten minutes pauses that phone's attempts.

## Keep the secret key out

The Supabase **secret key** is not used by the app or by these pages, and must never be put in them.
If it has been shared anywhere, replace it in Supabase → Project Settings → API Keys.
