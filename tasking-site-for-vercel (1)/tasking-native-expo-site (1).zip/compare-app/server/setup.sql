-- Tasking access codes: run this ONCE in Supabase → SQL Editor → New query → Run.
-- It is safe to run again; it does not delete existing codes.
--
-- Nothing here is readable or writable directly from the app or a browser.
-- Every action goes through the functions below, which do their own checks.

create table if not exists public.access_codes (
  code        text primary key,
  label       text not null default '',          -- who the code was issued to
  max_devices int  not null default 1 check (max_devices between 1 and 50),
  valid_days  int  not null default 30 check (valid_days between 1 and 3650),
  expires_at  timestamptz,                       -- set when the code is first activated
  revoked     boolean not null default false,
  created_at  timestamptz not null default now()
);

create table if not exists public.activations (
  code         text not null references public.access_codes(code) on delete cascade,
  device_id    text not null,
  activated_at timestamptz not null default now(),
  last_seen    timestamptz not null default now(),
  primary key (code, device_id)
);

create table if not exists public.failed_attempts (
  device_id text not null,
  at        timestamptz not null default now()
);
create index if not exists failed_attempts_device_at on public.failed_attempts (device_id, at);

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- Row level security on, with no policies: only the functions below can touch these tables.
alter table public.access_codes    enable row level security;
alter table public.activations     enable row level security;
alter table public.failed_attempts enable row level security;
alter table public.admins          enable row level security;

create or replace function public.clean_code(p text) returns text
language sql immutable as $$ select upper(regexp_replace(coalesce(p, ''), '\s+', '', 'g')) $$;

-- ---------- used by the app ----------

-- Binds a device to a code. Returns {ok, reason?, expires_at?, label?}.
create or replace function public.activate_code(p_code text, p_device text) returns json
language plpgsql security definer set search_path = public as $$
declare
  v_code text := clean_code(p_code);
  v_dev  text := left(coalesce(p_device, ''), 80);
  c      access_codes%rowtype;
  used   int;
begin
  if length(v_dev) < 8 then return json_build_object('ok', false, 'reason', 'bad_device'); end if;

  -- slow down guessing: 8 wrong codes from one device in 10 minutes locks it out for a while
  delete from failed_attempts where at < now() - interval '1 day';
  if (select count(*) from failed_attempts where device_id = v_dev and at > now() - interval '10 minutes') >= 8 then
    return json_build_object('ok', false, 'reason', 'too_many');
  end if;

  select * into c from access_codes where code = v_code for update;
  if not found then
    insert into failed_attempts (device_id) values (v_dev);
    return json_build_object('ok', false, 'reason', 'invalid');
  end if;
  if c.revoked then return json_build_object('ok', false, 'reason', 'revoked'); end if;
  if c.expires_at is not null and c.expires_at <= now() then return json_build_object('ok', false, 'reason', 'expired'); end if;

  if exists (select 1 from activations where code = v_code and device_id = v_dev) then
    update activations set last_seen = now() where code = v_code and device_id = v_dev;
  else
    select count(*) into used from activations where code = v_code;
    if used >= c.max_devices then return json_build_object('ok', false, 'reason', 'device_limit'); end if;
    insert into activations (code, device_id) values (v_code, v_dev);
  end if;

  if c.expires_at is null then
    c.expires_at := now() + make_interval(days => c.valid_days);
    update access_codes set expires_at = c.expires_at where code = v_code;
  end if;
  return json_build_object('ok', true, 'expires_at', c.expires_at, 'label', c.label);
end $$;

-- Called each time the app opens. Returns {ok, reason?, expires_at?}.
create or replace function public.check_access(p_code text, p_device text) returns json
language plpgsql security definer set search_path = public as $$
declare
  v_code text := clean_code(p_code);
  c      access_codes%rowtype;
begin
  select * into c from access_codes where code = v_code;
  if not found then return json_build_object('ok', false, 'reason', 'invalid'); end if;
  if c.revoked then return json_build_object('ok', false, 'reason', 'revoked'); end if;
  if c.expires_at is not null and c.expires_at <= now() then return json_build_object('ok', false, 'reason', 'expired'); end if;
  update activations set last_seen = now() where code = v_code and device_id = p_device;
  if not found then return json_build_object('ok', false, 'reason', 'not_activated'); end if;
  return json_build_object('ok', true, 'expires_at', c.expires_at);
end $$;

-- Used by the customer page. Only someone who already has the code can look it up.
create or replace function public.code_status(p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare
  v_code text := clean_code(p_code);
  c      access_codes%rowtype;
begin
  select * into c from access_codes where code = v_code;
  if not found then return json_build_object('found', false); end if;
  return json_build_object(
    'found', true, 'revoked', c.revoked, 'expires_at', c.expires_at, 'valid_days', c.valid_days,
    'expired', c.expires_at is not null and c.expires_at <= now(),
    'max_devices', c.max_devices,
    'devices_used', (select count(*) from activations where code = v_code));
end $$;

-- ---------- used by the admin page (signed-in admins only) ----------

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admins where user_id = auth.uid())
$$;

-- The first signed-in user to call this becomes the admin. After that it only reports status.
create or replace function public.admin_claim() returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return false; end if;
  if not exists (select 1 from admins) then insert into admins (user_id) values (auth.uid()); end if;
  return is_admin();
end $$;

create or replace function public.admin_list_codes() returns json
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  return coalesce((
    select json_agg(row_to_json(t) order by t.created_at desc) from (
      select c.code, c.label, c.max_devices, c.valid_days, c.expires_at, c.revoked, c.created_at,
             coalesce((select json_agg(json_build_object('device_id', a.device_id, 'activated_at', a.activated_at, 'last_seen', a.last_seen) order by a.activated_at)
                       from activations a where a.code = c.code), '[]'::json) as devices
      from access_codes c
    ) t), '[]'::json);
end $$;

-- Makes a code like TASK-2026-7K3QXM9D, or uses the one given.
create or replace function public.admin_create_code(p_label text, p_max_devices int default 1, p_valid_days int default 30, p_code text default null) returns text
language plpgsql security definer set search_path = public as $$
declare
  v_code text := nullif(clean_code(p_code), '');
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- no 0/O or 1/I, so codes are easy to read out
  tail text;
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if v_code is not null and v_code !~ '^[A-Z0-9]{2,8}(-[A-Z0-9]{2,8}){1,3}$' then
    raise exception 'A custom code must look like TASK-2026-AB12';
  end if;
  while v_code is null loop
    select string_agg(substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1), '') into tail from generate_series(1, 8);
    v_code := 'TASK-' || to_char(now(), 'YYYY') || '-' || tail;
    if exists (select 1 from access_codes where code = v_code) then v_code := null; end if;
  end loop;
  insert into access_codes (code, label, max_devices, valid_days)
    values (v_code, coalesce(p_label, ''), coalesce(p_max_devices, 1), coalesce(p_valid_days, 30));
  return v_code;
end $$;

create or replace function public.admin_set_revoked(p_code text, p_revoked boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  update access_codes set revoked = p_revoked where code = clean_code(p_code);
end $$;

-- Adds days. An expired code restarts from today; an unused code just gets a longer first window.
create or replace function public.admin_extend(p_code text, p_days int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  update access_codes
     set expires_at = case when expires_at is null then null else greatest(expires_at, now()) + make_interval(days => p_days) end,
         valid_days = case when expires_at is null then least(valid_days + p_days, 3650) else valid_days end
   where code = clean_code(p_code);
end $$;

-- Frees the code's device slots, e.g. when a customer changes phone.
create or replace function public.admin_reset_devices(p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  delete from activations where code = clean_code(p_code);
end $$;

create or replace function public.admin_delete_code(p_code text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  delete from access_codes where code = clean_code(p_code);
end $$;

-- Who may call what.
revoke all on all functions in schema public from public;
grant execute on function public.activate_code(text, text), public.check_access(text, text), public.code_status(text) to anon, authenticated;
grant execute on function public.is_admin(), public.admin_claim(), public.admin_list_codes(),
  public.admin_create_code(text, int, int, text), public.admin_set_revoked(text, boolean),
  public.admin_extend(text, int), public.admin_reset_devices(text), public.admin_delete_code(text) to authenticated;

-- ---------- website: customer sign-in and app download ----------

-- Small settings the admin edits from the panel (the APK link and its version label).
create table if not exists public.app_settings (
  key   text primary key,
  value text not null default ''
);
alter table public.app_settings enable row level security;

-- Customer sign-in on the website. The access code is the login.
-- The download link is only handed out for a code that is usable (not switched off, not expired).
create or replace function public.customer_portal(p_code text) returns json
language plpgsql security definer set search_path = public as $$
declare
  v_code text := clean_code(p_code);
  c      access_codes%rowtype;
  usable boolean;
begin
  select * into c from access_codes where code = v_code;
  if not found then return json_build_object('found', false); end if;
  usable := not c.revoked and (c.expires_at is null or c.expires_at > now());
  return json_build_object(
    'found', true, 'code', c.code, 'label', c.label, 'revoked', c.revoked,
    'expires_at', c.expires_at, 'valid_days', c.valid_days,
    'expired', c.expires_at is not null and c.expires_at <= now(),
    'max_devices', c.max_devices,
    'devices_used', (select count(*) from activations where code = v_code),
    'apk_url', case when usable then (select value from app_settings where key = 'apk_url') end,
    'apk_version', (select value from app_settings where key = 'apk_version'));
end $$;

create or replace function public.admin_get_settings() returns json
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  return coalesce((select json_object_agg(key, value) from app_settings), '{}'::json);
end $$;

create or replace function public.admin_set_setting(p_key text, p_value text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() then raise exception 'Admins only'; end if;
  if p_key not in ('apk_url', 'apk_version') then raise exception 'Unknown setting'; end if;
  if p_key = 'apk_url' and coalesce(p_value, '') <> '' and p_value !~ '^https://' then raise exception 'The download link must start with https://'; end if;
  insert into app_settings (key, value) values (p_key, coalesce(p_value, ''))
  on conflict (key) do update set value = excluded.value;
end $$;

revoke all on function public.customer_portal(text), public.admin_get_settings(), public.admin_set_setting(text, text) from public;
grant execute on function public.customer_portal(text) to anon, authenticated;
grant execute on function public.admin_get_settings(), public.admin_set_setting(text, text) to authenticated;
