// Open-licence reference images for trap tasks: Openverse first, Wikimedia Commons as a fallback.
export type SourceImage = { title: string; url: string; thumb: string; page: string; source: string; license: string };

async function getJson(url: string): Promise<any> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 20_000);
  try {
    const res = await fetch(url, { signal: ctl.signal, headers: { accept: "application/json" } });
    if (!res.ok) throw new Error(`Search answered ${res.status}.`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

const clean = (v: unknown) => String(v ?? "").replace(/<[^>]+>/g, "").trim();

async function openverse(q: string): Promise<SourceImage[]> {
  const data = await getJson(`https://api.openverse.org/v1/images/?q=${encodeURIComponent(q)}&page_size=6`);
  return (Array.isArray(data?.results) ? data.results : []).map((r: any) => ({
    title: clean(r.title) || "Open-source image",
    url: clean(r.url),
    thumb: clean(r.thumbnail) || clean(r.url),
    page: clean(r.foreign_landing_url),
    source: clean(r.source || r.provider) || "Openverse",
    license: [clean(r.license).toUpperCase(), clean(r.license_version)].filter(Boolean).join(" ") || "Open licence",
  }));
}

async function commons(q: string): Promise<SourceImage[]> {
  const data = await getJson(
    `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrnamespace=6&gsrlimit=6&gsrsearch=${encodeURIComponent(q)}&prop=imageinfo&iiprop=url|extmetadata&iiurlwidth=640`,
  );
  const pages = Object.values(data?.query?.pages ?? {}) as any[];
  return pages.map((p) => {
    const info = p.imageinfo?.[0] ?? {};
    return {
      title: clean(p.title).replace(/^File:/, "") || "Open-source image",
      url: clean(info.url),
      thumb: clean(info.thumburl) || clean(info.url),
      page: clean(info.descriptionurl),
      source: "Wikimedia Commons",
      license: clean(info.extmetadata?.LicenseShortName?.value) || "Open licence",
    };
  });
}

export async function searchSourceImages(query: string): Promise<SourceImage[]> {
  const q = query.trim();
  if (!q) throw new Error("Enter a niche or image topic to search.");
  const usable = (list: SourceImage[]) => list.filter((s) => /^https:\/\//.test(s.thumb || s.url));
  let found: SourceImage[] = [];
  try { found = usable(await openverse(q)); } catch { /* fall through to Commons */ }
  if (found.length === 0) {
    try { found = usable(await commons(q)); } catch { throw new Error("Open-source image search failed. Check your connection and try again."); }
  }
  if (found.length === 0) throw new Error("No open-source matches were found. Try a more specific search.");
  return found.slice(0, 6);
}
