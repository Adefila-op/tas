// Image preparation shared by guides and comparisons.
// Everything sent to the judge is a JPEG no larger than maxSide on its long edge,
// so payloads stay small and the declared media type is always true.
import * as FileSystem from "expo-file-system/legacy";
import { ImageManipulator, SaveFormat } from "expo-image-manipulator";

const readBase64 = (uri: string) => FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });

export async function toJpegBase64(uri: string, maxSide = 1600, compress = 0.7): Promise<string> {
  try {
    const ctx = ImageManipulator.manipulate(uri);
    let ref = await ctx.renderAsync();
    if (Math.max(ref.width, ref.height) > maxSide) {
      ctx.resize(ref.width >= ref.height ? { width: maxSide } : { height: maxSide });
      ref = await ctx.renderAsync();
    }
    const out = await ref.saveAsync({ format: SaveFormat.JPEG, compress, base64: true });
    return out.base64 || (await readBase64(out.uri));
  } catch {
    // If the image can't be re-encoded, send the original bytes rather than fail the whole comparison.
    return readBase64(uri);
  }
}
